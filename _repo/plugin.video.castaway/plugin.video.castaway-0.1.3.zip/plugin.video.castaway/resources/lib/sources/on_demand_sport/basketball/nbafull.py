from __future__ import unicode_literals
from resources.lib.modules import client,webutils,convert
import re,urlparse,urllib,sys,os,urllib2,json,cookielib
from resources.lib.modules.log_utils import log
from addon.common.addon import Addon
addon = Addon('plugin.video.castaway', sys.argv)

AddonPath = addon.get_path()
IconPath = AddonPath + "/resources/media/"
def icon_path(filename):
    return os.path.join(IconPath, filename)

class info():
    def __init__(self):
    	self.mode = 'nbafull'
        self.name = 'nbafull.com (full replays)'
        self.icon = 'nbafull.png'
        self.paginated = True
        self.categorized = False
        self.multilink = True


class main():
	def __init__(self,url = 'http://nbafull.com'):
		self.base = 'http://nbafull.com'
		self.url = url

	def items(self):
		html = client.request(self.url)
		soup = webutils.bs(html)
		items=soup.findAll('div',{'class':'thumb'})
		out=[]
		for item in items:
			url = item.find('a')['href']
			title=item.find('a')['title'].encode('utf-8')
			title = re.sub('<[^>]*>','',title)
			out+=[[title,url,icon_path(info().icon)]]

		return out

	def links(self,url, img=' '):
		if 'nbafull.com' not in url:
			url = self.base + url
		ref = url
		out = []
		html = client.request(url)
		html = convert.unescape(html.decode('utf-8'))
		soup = webutils.bs(html)

		#dailys = re.findall('(http://www.dailymotion.com/video/[^\"\']+)[\"\']',html)
		dailys = re.findall('src=[\"\'](//(?:www.)?dailymotion.com/embed/video/[^\"\']+)[\"\']',html)
		vks = re.findall('src=[\"\'](//(?:www.)?vk.com/video_ext.php[^\"\']+)[\"\']',html)
		gvid720 = re.findall('src=[\"\'](https?://.+?google.+?/[^\"\']+)" type=[\"\']video/mp4[\"\'] data-res=[\"\']720p[\"\']',html)
		gvid360 = re.findall('src=[\"\'](https?://.+?google.+?[^\"\']+)" type=[\"\']video/mp4[\"\'] data-res=[\"\']360p[\"\']',html)
		mailru = re.findall('(https?://(?:www.)?videoapi.my.mail.ru/videos/[^\"\']+)[\"\']',html)
		opnld = re.findall('(https?://(?:www.)?openload.co/embed/[^\"\']+)[\"\']',html)

		i = 0
		for v in dailys:
			i+=1
			title = 'Dailymotion video %s'%i
			url = v
			out.append((title,url,icon_path(info().icon)))

		i = 0
		for v in vks:
			i+=1
			title = 'VK.com video %s'%i
			url = v
			out.append((title,url,icon_path(info().icon)))

		i = 0
		for v in opnld:
			i+=1
			title = 'Openload link %s'%i
			url = v
			out.append((title,url,icon_path(info().icon)))
		i = 0
		for v in gvid720:
			i+=1
			title = 'GVIDEO link %s 720p'%i
			url = v
			out.append((title,url,icon_path(info().icon)))
		i = 0
		for v in gvid360:
			i+=1
			title = 'GVIDEO link %s 360p'%i
			url = v
			out.append((title,url,icon_path(info().icon)))
		i = 0
		for v in mailru:
			link = v
			i+=1
			title = 'Mail.ru video %s'%i
			link = link.replace('https://videoapi.my.mail.ru/videos/embed/mail/','http://videoapi.my.mail.ru/videos/mail/')
			link = link.replace('html','json')
			cookieJar = cookielib.CookieJar()
			opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookieJar), urllib2.HTTPHandler())
			conn = urllib2.Request(link)
			connection = opener.open(conn)
			f = connection.read()
			connection.close()
			js = json.loads(f)
			for cookie in cookieJar:
				token = cookie.value
			js = js['videos']
			for x in js:
				url = x['url'] + '|%s'%(urllib.urlencode({'Cookie':'video_key=%s'%token, 'User-Agent':client.agent(), 'Referer':ref} ))
				title = 'Mail.ru video ' + x['key']
				out.append((title,url,icon_path(info().icon)))

		if 'Please waiting uploading' in html and len(out)==0:
			out.append(('No videos uploaded yet.','x',icon_path(info().icon)))


		return out





	def resolve(self,url):

		if url=='x':
			return
		if 'mail.ru' in url:
			return url

		if url.startswith('//'):
			url = 'http:' + url

		import urlresolver
		return urlresolver.resolve(url)




	def next_page(self):

		html = client.request(self.url)
		try:
			next_page=re.findall('<a.+?rel="next".+?href="(.+?)"',html)[0]
			if 'nbafull.com' not in next_page:
				next_page = self.base + next_page
		except:
			next_page=None
		return next_page


