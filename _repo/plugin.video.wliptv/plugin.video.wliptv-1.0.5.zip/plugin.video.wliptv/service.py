try:
    import recordings
    recordings.reschedule()
except:
    pass
