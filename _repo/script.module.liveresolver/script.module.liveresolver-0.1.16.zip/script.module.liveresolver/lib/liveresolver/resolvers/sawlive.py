# -*- coding: utf-8 -*-
import re,urllib,urlparse,base64
from liveresolver.modules import client
from liveresolver.modules import jsunpack
from liveresolver.modules.log_utils import log




def resolve(url):
    try:

        page = re.compile('//(.+?)/(?:embed|v)/([0-9a-zA-Z-_]+)').findall(url)[0]
        page = 'http://%s/embed/%s' % (page[0], page[1])
        try: referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
        except: referer = page
        try: host = urlparse.parse_qs(urlparse.urlparse(url).query)['host'][0]
        except: host = 'sawlive.tv'

        headers={'User-Agent': client.agent(),'Host': host, 'Referer': referer, 'Connection': 'keep-alive'}
        
        result = client.request(page, referer=referer)
        unpacked = ''
        packed = result.split('\n')
        for i in packed: 
            try: unpacked += jsunpack.unpack(i)
            except: pass
        result += unpacked
        result = urllib.unquote_plus(result)
        result = re.sub('\s\s+', ' ', result)
        url = client.parseDOM(result, 'iframe', ret='src')[-1]
        url = url.replace(' ', '')
        var = re.compile('var\s(.+?)\s*=\s*[\'\"](.+?)[\'\"]').findall(result)
        for i in range(100):
            for v in var: result = result.replace(" %s " % v[0], ' %s '%v[1])
        var = re.compile('var\s(.+?)\s*=\s*[\'\"](.+?)[\'\"]').findall(result)

        for i in range(100):
            for v in var: url = url.replace("'%s'" % v[0], v[1].replace('"','').replace(' ',''))
            for v in var: url = url.replace("(%s)" % v[0], "(%s)" % v[1].replace('"','').replace(' ',''))
        result = re.sub(r"unescape\((.+?)\)", r'\1', result)
        url = re.sub(r"'unescape\((.+?)\)'", r'\1', url)
        url = re.sub(r"'(.+?)'", r'\1', url)

        result = client.request(url, headers=headers)
        if result == None:
            try:
                log("Sawlive: Importing js2py...")    
                import js2py
                log("Successfull!")
            except Exception as e:
                log("Sawlive: Js2py import exception:\n" + str(e))
                return
            #js functions replaced
            funcs = re.findall('(function\s*(.+?)\((.+?)\)\s*{.+?\})',result)
            params = re.findall(r"(un.+?)\((.+?)\)", url)
            log("Sawlive: Using js2py module")
            for f in funcs:
                fun = js2py.eval_js(f[0])
                for p in params:
                    if p[0]==f[1]:
                        res = fun(p[1])
                        url = url.replace("{}({})".format(f[1],p[1]),res)
            result = client.request(url, headers=headers)

            
            
        
        file = re.compile("'file'.+?'(.+?)'").findall(result)[0]
        log("Sawlive: Found file url: " + file)
        try:
            log("Sawlive: Finding m3u8 link.")
            if not file.startswith('http'): raise Exception()
            url = client.request(file, output='geturl')
            if not '.m3u8' in url: raise Exception()
            url += '|%s' % urllib.urlencode({'User-Agent': client.agent(), 'Referer': file})
            log("Sawlive: Found m3u8 link: " + url)
            return url
        except:
            log("Sawlive: m3u8 link not found, finding rtmp.")
            pass

        strm = re.compile("'streamer'.+?'(.+?)'").findall(result)[0]
        swf = re.compile("SWFObject\('(.+?)'").findall(result)[0]

        url = '%s playpath=%s swfUrl=%s pageUrl=%s live=1 timeout=30' % (strm, file, swf, url)
        url = urllib.unquote(url)
        log("Sawlive: rtmp link found: " + url)
        return url
    except Exception as e:
        log("Sawlive exception:\n" + str(e))
        log("Sawlive: Resolver failed. Returning...")
        return


