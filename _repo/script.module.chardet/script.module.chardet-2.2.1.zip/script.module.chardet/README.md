xbmc-chardet
============

chardet library module packed for XBMC