Im85288's XBMC Repository
=========================

* Date:		November, 2013
* Version:	1.0.0
* Github:	<https://github.com/im85288/im85288-xbmc-repo>

Hello There!

This is my XBMC Addon repository! Here I host addons that I have made or modified for XBMC, such as Xperience1080++ and Plexbmc

Usage
-----
Simply download the repository zip and install it, or use XBMC's repository installer plugin.

Questions, Comments, Concerns, Issues
-------------------------------------
If you have any of these, go ahead and [submit an issue](https://github.com/im85288/im85288-xbmc-repo/issues),
List of addons available
------------------------
* Xperience1080++
* PleXbmc

