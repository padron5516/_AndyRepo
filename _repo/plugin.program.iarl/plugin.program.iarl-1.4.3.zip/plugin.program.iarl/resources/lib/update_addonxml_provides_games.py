from util import *

update_addonxml('game')