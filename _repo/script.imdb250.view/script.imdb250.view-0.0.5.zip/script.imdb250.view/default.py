# import the XBMC libraries so we can use the controls and functions of XBMC
import xbmc, xbmcgui

xbmc.executebuiltin("XBMC.ActivateWindow(videos,special://profile/playlists/video/IMDbTop250.xsp,return)")
 
xbmc.executebuiltin("XBMC.Container.Refresh")