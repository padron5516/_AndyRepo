# -*- coding: utf-8 -*-
from time import strftime
from datetime import datetime
import mechanize,cookielib,xbmcaddon,os,requests
import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,base64
br = mechanize.Browser()
# Enable cookie support for urllib2 
cookiejar = cookielib.LWPCookieJar() 
br.set_cookiejar( cookiejar ) 
PLUGIN='plugin.video.VADER'
ADDON = xbmcaddon.Addon(id=PLUGIN)
username = ADDON.getSetting('user')
password = ADDON.getSetting('pass')
firstrun = ADDON.getSetting('first')
login = ADDON.getSetting('login')
datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
_addon = xbmcaddon.Addon()
_path = _addon.getAddonInfo("path")
addonDir = ADDON.getAddonInfo('path').decode("utf-8")
secret = ('http://c0mmandpr0tv.ddns.me:8000/panel_api.php?username=%s&password=%s'%(username,password))
BASE = ('http://c0mmandpr0tv.ddns.me:8000/')
STREAM = ('http://c0mmandpr0tv.ddns.me:8000/live/%s/%s/'%(username,password))
def intro():
    if firstrun == 'yes':
        PLAYVIDEO(addonDir+'/resources/vader.mp4','intro')
        CATEGORIES()
        ADDON.setSetting('first','no')
    else:
        CATEGORIES()
def GETCAT():
    list2 = []
    r = requests.get(secret)
    match=re.compile('category_id":"(.+?)","category_name":"(.+?)"').findall(r.content)
    for catagory_id,category_name in match:
        list2.append(category_name+'['+catagory_id+']')
        list(set(list2))
        for e in list(set(list2)):
            if e not in list(set(list2)):
                list(set(list2.append))(e)
        LF = open('%s/CATS.TXT'%datapath, 'w')
        LF.write('%s\n'%list(set(list2)))
        LF.close
def CATEGORIES():
    if login == '1':
        addDir('Vaders Live TV','s',22,'C:\Users\J\Desktop\Vader Streams\Sections\Live.png')
        addDir('Vaders Account Zone','a',19,'C:\Users\J\Desktop\Vader Streams\Sections\Account.png')
        addDir2('Vaders Settings Zone','a',20,'C:\Users\J\Desktop\Vader Streams\Sections\Setting.png')
        addDir2('Logout','a',15,'C:\Users\J\Desktop\Vader Streams\Sections\Logout.png')
    else:
        addDir2('[COLOR red]Please have your Vader Streams Account Ready![/COLOR]','s',21,'C:\Users\J\Desktop\Vader Streams\New folder (2)\New folder (2)\icon.png')
        addDir2('Login','a',14,'C:\Users\J\Desktop\Vader Streams\Sections\Login.png')
def LOGIN():
    tecleado = keyboard_input('','Username')
    set_setting('user',tecleado)
    tecleado2 = keyboard_input('','Password')
    set_setting('pass',tecleado2)
    r = requests.get(BASE+'panel_api.php?'+'&username='+tecleado+'&password='+tecleado2)
    match=re.compile('auth":(.+?)').findall(r.text)
    for auth in match:
        if auth == '1':
            dialog = xbmcgui.Dialog()
            dialog.ok('You Are Now Logged in', 'THANK YOU !')
            set_setting('login','1')
            GETCAT()
            xbmc.executebuiltin('Container.Refresh')
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok('There Was Somthing Wrong', 'INCORRECT !') 
def LIVE():
    GETCAT()
    link = open('%s/CATS.TXT'%datapath,'r')
    match=re.compile("'(.+?)\[(.+?)]'").findall(link.read())
    addDir('ALL CHANNELS','s',11,'')
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE )
    link.close
    for name,url in match:
        addDir('[COLOR red]%s[/COLOR]'%name,url,21,'')
def LOGOUT():
    set_setting('user','')
    set_setting('pass','')
    set_setting('login','0')
    xbmc.executebuiltin('Container.Refresh')
    return

def ACCOUNT():
    r = requests.get(secret)
    match=re.compile('"username":"(.+?)".+?uth":(.+?),".+?tus":"(.+?)".+?_date":(.+?),"is_trial":"(.+?)".+?ve_cons":"(.+?)".+?ed_at":"(.+?)".+?ctions":"(.+?)".+?output_formats":(.+?)\]').findall(r.content)
    for username,password,auth,status,exp_date,is_trial1,is_trial,active_cons,created_ats in match:
        addDir('[COLOR yellow]ACCOUNT Username:[/COLOR] %s'%username,'','','')
        addDir('[COLOR yellow]ACCOUNT Is Trial:[/COLOR] %s'%is_trial1,'','','')
        timerdate = datetime.fromtimestamp(int(is_trial)).strftime('%Y-%m-%d %H:%M:%S')
        addDir('[COLOR yellow]ACCOUNT EXPIRE DATE:[/COLOR] %s'%timerdate,'','','')




def set_setting(name,value):
    ADDON.setSetting( name,value )

def open_settings_dialog():
    ADDON.openSettings()
def keyboard_input(default_text="", title="", hidden=False):
    keyboard = xbmc.Keyboard(default_text,title,hidden)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        tecleado = keyboard.getText()
    else:
        tecleado = ""
    return tecleado
def OPEN_URL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        req.add_header('Referer', '%s'%url)
        req.add_header('Connection', 'keep-alive')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def ONDEMAND():
    menu=[]
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE )
    r = requests.get(secret)
    match=re.compile('"name":"(.+?)".+?stream_id":"(.+?)".+?hannel_id"(.+?).".+?y_id":"(.+?)".+?name".+?nsion".+?icon":"(.+?)"').findall(r.content)
    for name,streamid,epg,CAT,icon in match:
            if epg == ':null':
                addDir2('%s'%(name),'%s%s.m3u8'%(STREAM,streamid),10,icon)
            else:
                r = requests.get('%s&action=get_epg&stream_id=%s'%(secret,streamid))
                match = re.compile('\[\{"title":"(.+?)",".+?","channel_id":".+?","description":(.+?)}').findall(r.content)
                list = []
                list2 = []
                for prog,description in match:
                    ret = list.append(prog)
                    ret2 = list2.append(description)
                    decode = base64.b64decode(list[0])
                    list2[0] = list2[0].replace('"','')
                    decode2 = base64.b64decode(list2[0])
                    addDir2('[COLOR red][B]%s[/B][/COLOR] [ [COLOR orange]Now: [/COLOR] %s ]-[ [COLOR blue][I]%s[/I][/COLOR]]'%(name,decode,decode2),'%s%s.m3u8'%(STREAM,streamid),10,icon)


def CAT(url):
    menu=[]
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE )
    r = requests.get(secret)
    match=re.compile('"name":"(.+?)".+?stream_id":"(.+?)".+?hannel_id"(.+?).".+?y_id":"(.+?)".+?name".+?nsion".+?icon":"(.+?)"').findall(r.content)
    for name,streamid,epg,CAT,icon in match:
        if url in CAT:
            if epg == ':null':
                addDir2('%s'%(name),'%s%s.m3u8'%(STREAM,streamid),10,icon)
            else:
                r = requests.get('%s&action=get_epg&stream_id=%s'%(secret,streamid))
                match = re.compile('\[\{"title":"(.+?)",".+?","channel_id":".+?","description":(.+?)}').findall(r.content)
                list = []
                list2 = []
                for prog,description in match:
                    ret = list.append(prog)
                    ret2 = list2.append(description)
                    decode = base64.b64decode(list[0])
                    list2[0] = list2[0].replace('"','')
                    decode2 = base64.b64decode(list2[0])
                    addDir2('[COLOR red][B]%s[/B][/COLOR] [[COLOR orange]Now:[/COLOR] %s ]-[ [I][COLOR blue]%s[/COLOR][/I]]'%(name,decode,decode2),'%s%s.m3u8'%(STREAM,streamid),10,icon)

def PLAYVIDEO(url,name):
        dp = xbmcgui.DialogProgress()
        dp.create('Featching Your Video','Featching Your Video')
        dp.update(0,'%s'%name)
        xbmc.sleep(1)
        play=xbmc.Player(GetPlayerCore())
        dp.update(100,'%s'%name)
        xbmc.sleep(1)
        play.play(url)
        dp.close()
def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
        except:
            pass
def PLAYVIDEO2(url):
    import urlresolver
    from urlresolver import common
    play=xbmc.Player(GetPlayerCore())
    url=urlresolver.HostedMediaFile(url).resolve()
    play.play(url)
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def addDir2(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        intro()
       
elif mode==1:
        print ""+url
        INDEX(url)

elif mode==10:
        PLAYVIDEO(url,name)
elif mode==11:
        ONDEMAND()
elif mode==12:
        PLAYVIDEO2(url)
elif mode==14:
        LOGIN()
elif mode==15:
        LOGOUT()
elif mode==19:
        ACCOUNT()
elif mode==20:
        open_settings_dialog()
elif mode==21:
        CAT(url)
elif mode==22:
        LIVE()



xbmcplugin.endOfDirectory(int(sys.argv[1]))

    