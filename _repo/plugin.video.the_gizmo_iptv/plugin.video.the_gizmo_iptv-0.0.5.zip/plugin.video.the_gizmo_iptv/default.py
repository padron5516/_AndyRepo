# -*- coding: utf-8 -*-
#Thanks to Avigdor 
import urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json
import repoCheck, re,urllib2
import xbmcvfs
import re

AddonID = 'plugin.video.the_gizmo_iptv'
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')
gizmo_code= Addon.getSetting('gizmo_code')
m3u_url = 'http://tinyurl.com/'+gizmo_code

addonDir = Addon.getAddonInfo('path')
favoritesFile = xbmc.translatePath(os.path.join(addonDir,'favorites.txt'))
tmpListFile = xbmc.translatePath(os.path.join(addonDir,'tempList.txt'))
image='http://www.xunitytalk.com/oss/'
libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import common
#from metahandler import metahandlers

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)
if not os.path.exists(addon_data_dir):
    os.makedirs(addon_data_dir)
    

#Metahandler
def GRABMETA(name,types,year=None):
    from metahandler import metahandlers
    type = types
    if year=='': year=None
    EnableMeta = Addon.getSetting('Enable-Meta')
    #
    if year==None:
        try: year=re.search('\s*\((\d\d\d\d)\)',name).group(1)
        except: year=None
    if year is not None: name=name.replace(' ('+year+')','').replace('('+year+')','')
    #
    if EnableMeta == 'true':
        if 'Movie' in type:
            ### grab.get_meta(media_type, name, imdb_id='', tmdb_id='', year='', overlay=6)
            meta = grab.get_meta('movie',name,'',None,year,overlay=6)
            infoLabels = {'rating': meta['rating'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],'director': meta['director'],'cast': meta['cast'],'backdrop_url': meta['backdrop_url'],'backdrop_url': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
        elif 'tvshow' in type:
            meta = grab.get_meta('tvshow',name,'','',year,overlay=6)
            infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'cast': meta['cast'],'studio': meta['studio'],'banner_url': meta['banner_url'],'backdrop_url': meta['backdrop_url'],'status': meta['status']}
    else: infoLabels=[]
    return infoLabels
 
def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Live TV","Downloading Latest TV List")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()

 
url ='https://the-gizmo.svn.beanstalkapp.com/itv/addons/playlist file/playLists.txt'

    
def Categories():
        images_url = 'special://home/addons/plugin.video.the_gizmo_iptv/resources/images/'
    
#   repoCheck.UpdateRepo()
        AddDir("[COLOR white]Gizmo TV - Your Personal List[/COLOR]",'url', 4, icon)
        #AddDir("[COLOR blue]Gizmo TV - Bonus List[/COLOR]", "bonus" ,5 ,os.path.join(addonDir, "resources", "images", "bonus.png"))
    #list = common.ReadList(playlistsFile)
    #for item in list:
    #   mode = 1 if item["url"].find(".plx") > 0 else 2
    #   name = common.GetEncodeString(item["name"])
    #   AddDir("[COLOR blue]{0}[/COLOR]".format(name) ,item["url"], mode, images_url+"bonus.png")
    
    #AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10001).encode('utf-8')), "settings" , 20, os.path.join(addonDir, "resources", "images", "NewList.ico"), isFolder=False)
        AddDir("[COLOR white][B]{0}[/B][/COLOR]".format(localizedString(10003).encode('utf-8')), "favorites" ,30 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"))

def Customlist():
    images_url = 'https://the-gizmo.svn.beanstalkapp.com/gizmo/addons/images/'
    list = common.ReadList(playlistsFile)
    for item in list:
        mode = 1 if item["url"].find(".plx") > 0 else 2
        name = common.GetEncodeString(item["name"])
        AddDir("[COLOR blue]{0}[/COLOR]".format(name) ,item["url"], mode, images_url+"bonus.png")
        
    

def AddNewList():
    listName = GetKeyboardText(localizedString(10004).encode('utf-8')).strip()
    if len(listName) < 1:
        return

    method = GetSourceLocation(localizedString(10002).encode('utf-8'), [localizedString(10016).encode('utf-8'), localizedString(10017).encode('utf-8')])    
    #print method
    if method == -1:
        return
    elif method == 0:
        listUrl = GetKeyboardText(localizedString(10005).encode('utf-8')).strip()
    else:
        listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.plx|.m3u').decode("utf-8")
        if not listUrl:
            return
    
    if len(listUrl) < 1:
        return

    list = common.ReadList(playlistsFile)
    for item in list:
        if item["url"].lower() == listUrl.lower():
            xbmc.executebuiltin('Notification({0}, "{1}" {2}, 5000, {3})'.format(AddonName, listName, localizedString(10007).encode('utf-8'), icon))
            return
    list.append({"name": listName.decode("utf-8"), "url": listUrl})
    if common.SaveList(playlistsFile, list):
        print "test######################################"
        xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
    
def RemoveFromLists(url):
    list = common.ReadList(playlistsFile)
    for item in list:
        if item["url"].lower() == url.lower():
            list.remove(item)
            if common.SaveList(playlistsFile, list):
                xbmc.executebuiltin("XBMC.Container.Refresh()")
            break
            
def PlxCategory(url):
    tmpList = []
    list = common.plx2list(url)
    background = list[0]["background"]
    for channel in list[1:]:
        iconimage = "" if not channel.has_key("thumb") else common.GetEncodeString(channel["thumb"])
        name = common.GetEncodeString(channel["name"])
        if channel["type"] == 'playlist':
            AddDir("[COLOR blue][{0}][/COLOR]".format(name) ,channel["url"], 1, iconimage, background=background)
        else:
            AddDir(name, channel["url"], 3, iconimage, isFolder=False, background=background)
            tmpList.append({"url": channel["url"], "image": iconimage, "name": name.decode("utf-8")})
            
    common.SaveList(tmpListFile, tmpList)

def m3uCategory1(url):
    list = common.m3u2list(m3u_url)

    for channel in list:
        name = common.GetEncodeString(channel["display_name"])
        name = name.replace("_"," ").replace('Server','').replace('(2)','')
        #lowername = name.lower()
        iconimage = image+name.replace(' ','').replace('GREEK','').replace('UK','').replace('HD','').replace('USA','').replace('US','').replace('EU','').replace('GB','').lower()+'.png'
        AddDir(name ,channel["url"], 3, iconimage, isFolder=False)
        '''if Addon.getSetting('Enable-Meta') == 'true':
            img = iconimage
            if img != None: infoLabels = GRABMETA(name,'Movie')
            else: infoLabels = iconimage
            AddDir(name ,channel["url"], 3, infoLabels, isFolder=False)
        else:
            AddDir(name ,channel["url"], 3, iconimage, isFolder=False)'''
            
def m3uCategory(url):   
    tmpList = []
    list = common.m3u2list(url)

    for channel in list:
        name = common.GetEncodeString(channel["display_name"])
        name = name.replace("_"," ")
        AddDir(name ,channel["url"], 3, "", isFolder=False)
        tmpList.append({"url": channel["url"], "image": "", "name": name.decode("utf-8")})

    common.SaveList(tmpListFile, tmpList)
        
def PlayUrl(name, url, iconimage=None):
        _NAME_=name
        list = common.m3u2list(m3u_url)
        for channel in list:
            name = common.GetEncodeString(channel["display_name"])
            stream=channel["url"]
            if _NAME_ in name:
                listitem = xbmcgui.ListItem(path=stream, thumbnailImage=iconimage)
                listitem.setInfo(type="Video", infoLabels={ "Title": name })
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def AddDir(name, url, mode, iconimage, description="", isFolder=True, background=None):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    a=sys.argv[0]+"?url=None&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    print name.replace('-[US]','').replace('-[EU]','').replace('[COLOR yellow]','').replace('[/COLOR]','').replace(' (G)','')+'='+a
    
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
    if background:
        liz.setProperty('fanart_image', background)
    if mode == 1 or mode == 2:
        liz.addContextMenuItems(items = [('{0}'.format(localizedString(10008).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url)))])
    elif mode == 3:
        liz.setProperty('IsPlayable', 'true')
        liz.addContextMenuItems(items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
    elif mode == 32:
        liz.setProperty('IsPlayable', 'true')
        liz.addContextMenuItems(items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
        
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

def GetKeyboardText(title = "", defaultText = ""):
    keyboard = xbmc.Keyboard(defaultText, title)
    keyboard.doModal()
    text =  "" if not keyboard.isConfirmed() else keyboard.getText()
    return text

def GetSourceLocation(title, list):
    dialog = xbmcgui.Dialog()
    answer = dialog.select(title, list)
    return answer
    
def AddFavorites(url, iconimage, name):
    favList = common.ReadList(favoritesFile)
    for item in favList:
        if item["url"].lower() == url.lower():
            xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
            return
    
    list = common.ReadList(tmpListFile) 
    for channel in list:
        if channel["name"].lower() == name.lower():
            url = channel["url"]
            iconimage = channel["image"]
            break
            
    if not iconimage:
        iconimage = ""
        
    data = {"url": url, "image": iconimage, "name": name.decode("utf-8")}
    
    favList.append(data)
    common.SaveList(favoritesFile, favList)
    xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))
    
def ListFavorites():
#    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10013).encode('utf-8')), "favorites" ,34 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"), isFolder=False)
    list = common.ReadList(favoritesFile)
    for channel in list:
        name = channel["name"].encode("utf-8")
        iconimage = channel["image"].encode("utf-8")
        AddDir(name, channel["url"], 32, iconimage, isFolder=False) 
        
def RemoveFavorties(url):
    list = common.ReadList(favoritesFile) 
    for channel in list:
        if channel["url"].lower() == url.lower():
            list.remove(channel)
            break
            
    common.SaveList(favoritesFile, list)
    xbmc.executebuiltin("XBMC.Container.Refresh()")
    
def AddNewFavortie():
    chName = GetKeyboardText("{0}".format(localizedString(10014).encode('utf-8'))).strip()
    if len(chName) < 1:
        return
    chUrl = GetKeyboardText("{0}".format(localizedString(10015).encode('utf-8'))).strip()
    if len(chUrl) < 1:
        return
        
    favList = common.ReadList(favoritesFile)
    for item in favList:
        if item["url"].lower() == url.lower():
            xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, localizedString(10011).encode('utf-8'), icon))
            return
            
    data = {"url": chUrl, "image": "", "name": chName.decode("utf-8")}
    
    favList.append(data)
    if common.SaveList(favoritesFile, favList):
        xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')".format(AddonID))

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0].lower()] = splitparams[1]
    return param

    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass

    
if mode == None or url == None or len(url) < 1:
    Categories()
elif mode == 1:
    PlxCategory(url)
elif mode == 2:
    m3uCategory(url)
elif mode == 3 or mode == 32:
    PlayUrl(name, url, iconimage)
elif mode == 4:
    m3uCategory1(url)
elif mode == 5:
        Customlist()
elif mode == 20:
    AddNewList()
elif mode == 22:
    RemoveFromLists(url)
elif mode == 30:
    ListFavorites()
elif mode == 31: 
    AddFavorites(url, iconimage, name) 
elif mode == 33:
    RemoveFavorties(url)
elif mode == 34:
    AddNewFavortie()
elif mode == 40:
    common.DelFile(playlistsFile)
    sys.exit()
elif mode == 41:
    common.DelFile(favoritesFile)
    sys.exit()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
