# MANY THANKS TO METALKETTLE, LAMBDA, PIPCAN, MUCKY DUCK, TITAN and THE ENTIRE KODI COMMUNITY FOR EVERYTHING THAT WE HAVE LEARNED.
# PEOPLE LIKE TARGET1080P CAN SUCK OUR BALLS.

import sys,os,json,urllib,urllib2,urlparse,xbmc,xbmcaddon,xbmcgui,xbmcplugin,hashlib,re,time,base64,shutil,unicodedata,pytz,urlresolver,random
from resources.lib.common_addon import net
from t0mm0.common.addon import Addon
from metahandler import metahandlers
from resources.lib.libraries import cache
from resources.lib.libraries import client
from resources.lib.resolvers import googleplus
from resources.lib.libraries import cloudflare




addon_id = 'plugin.video.dnatv'
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
tv_guide = xbmc.translatePath('special://home/addons/script.dnatvguide/')
usrdata = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.dnatv/')



addon = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir = xbmc.translatePath( addon.getAddonInfo('profile') ) 

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
plugin_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
dialog = xbmcgui.Dialog()
net = net.Net()



def Main():
	addDir1('[COLOR lime][B][I]       >>> Team DNA Presents DNA TV <<<[/B][/I][/COLOR]','',0,icon,fanart)
	addDir2('[COLOR yellow][B][I]>> Movies[/B][/I][/COLOR]','http://pastebin.com/raw/wicS4Pzp',3001,icon,fanart)
	addDir2('[COLOR yellow][B][I]>> TV Shows[/B][/I][/COLOR]','http://pastebin.com/raw/CjaSuY2n',3001,icon,fanart)
	addDir('[COLOR yellow][B][I]>> Live TV[/B][/I][/COLOR]','0',500,icon,fanart)
	addDir2('[COLOR yellow][B][I]>> Radio[/B][/I][/COLOR]','http://pastebin.com/raw/fvK5JHpN',3001,icon,fanart)
	addDir2('[COLOR yellow][B][I]>> Music[/B][/I][/COLOR]','http://pastebin.com/raw/2b7RCrXJ',3001,icon,fanart)
	
	addDir1('[COLOR blue][I]>> Clear KODI Cache[/I][/COLOR]','0',1003,icon,fanart)
	
	xbmc.executebuiltin('Container.SetViewMode(50)')
	xbmc.executebuiltin('Container.Update')

def livetv():
	addDir('[COLOR lime]>> DNA TV[/COLOR] [COLOR red]UKTVNOW Channels[/COLOR]','0',100,icon, fanart)
	addDir1('[COLOR lime]>> DNA TV[/COLOR] [COLOR red]Premium Channels (Coming Soon)[/COLOR]','',0,icon,fanart)
	addDir2('[COLOR red]>> Extra LIVE TV[/COLOR]','http://pastebin.com/raw/SGhZ9D64',3001,icon,fanart)
	addDir('[COLOR lime]>> DNA TV[/COLOR] [COLOR red]GUIDE[/COLOR]','0',1001,icon,fanart)
	
	xbmc.executebuiltin('Container.SetViewMode(50)')
	xbmc.executebuiltin('Container.Update')
	

def bonus_streams():
	addDir('[COLOR blue]UK Channels[/COLOR]','0',2101,icon, fanart)
	addDir('[COLOR blue]USA Channels[/COLOR]','0',2110,icon, fanart)
	addDir('[COLOR blue]Sports[/COLOR]','0',2105,icon, fanart)
	addDir('[COLOR blue]Movies[/COLOR]','0',2102,icon, fanart)
	addDir('[COLOR blue]Music[/COLOR]','0',2103,icon, fanart)
	addDir('[COLOR blue]Kids[/COLOR]','0',2107,icon, fanart)
	addDir('[COLOR blue]Science[/COLOR]','0',2106,icon, fanart)
	addDir('[COLOR blue]News[/COLOR]','0',2104,icon, fanart)

	
def DeleteCache(url):
    print '###DELETING KODI CACHE###'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
			
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete KODI Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
			else:
				pass
		

def dnatvguide():
	if not os.path.exists(tv_guide):
		dialog.ok(addonname, '[COLOR red]Please make sure you have the DNA TV Guide installed from the DNA Repository[/COLOR]')
	xbmc.executebuiltin("RunAddon(script.dnatvguide)")



def get_stream(url,name): 
    play=xbmc.Player(GetPlayerCore())
    import urlresolver
    try: 
		liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage); 
		liz.setInfo(type="Video", infoLabels={"Title": name })
		play.play(url, liz, False)
    except: 
		pass
			

def get_stream_dex(url,name):
        dp = xbmcgui.DialogProgress()
        dp.create('Loading','Please wait...')
        dp.update(0,'%s'%name)
        xbmc.sleep(1)
        play=xbmc.Player(GetPlayerCore())
        dp.update(100,'%s'%name)
        xbmc.sleep(1)
        play.play(url)
        dp.close()
	
			
def list_channels(genre):
	match = list_streams()
	for name,iconimage,stream1,stream2,cat in match:
	  if not 'Planett' in name:
		if name=='null':name='Channel'
		name=name.replace('"','').replace('.','').replace('Disnep','Disney')
		thumb='https://app.uktvnow.net/'+iconimage+'|User-Agent=Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G920F Build/LMY47X)'
		if int(cat)==genre:
			addLink1(name,'url',4000,thumb)
		
		
def local_time(zone='Asia/Karachi'):
	from datetime import datetime
	from pytz import timezone
	other_zone = timezone(zone)
	other_zone_time = datetime.now(other_zone)
	return other_zone_time.strftime('%B-%d-%Y')
	

def getAPIToken( url,  username):
	from pytz import timezone
	dt=local_time()
	s = "uktvnow-token-"+ dt + "-"+ "_|_-" + url + "-" + username +"-" + "_|_"+ "-"+ base64.b64decode("MTIzNDU2IUAjJCVedWt0dm5vd14lJCNAITY1NDMyMQ==")
	import hashlib
	return hashlib.md5(s).hexdigest()


def list_streams():
	token=getAPIToken('https://app.uktvnow.net/v1/get_all_channels','tvstreams')
	headers={'User-Agent':'USER-AGENT-UKTVNOW-APP-V1',
			 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
			 'Accept-Encoding' : 'gzip',
			 'app-token':token,
			 'Connection':'Keep-Alive',
			 'Host':'app.uktvnow.net'}
	postdata={'username':'admin'}
	channels = net.http_POST('https://app.uktvnow.net/v1/get_all_channels',postdata, headers).content
	channels = channels.replace('\/','/')
	match=re.compile('"channel_name":"(.+?)","img":"(.+?)","http_stream":"(.+?)","rtmp_stream":"(.+?)","cat_id":"(.+?)"').findall(channels)
	return match
	

def guideStream(name):
	match = list_streams()
	for name2,iconimage,stream1,stream2,cat in match:      
		name2=name2.replace('"','')
		thumb='https://app.uktvnow.net/'+iconimage+'|User-Agent=Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G920F Build/LMY47X)'     
		streamname=[]
		streamurl=[]
		streamthumb=[]
		if name2 == name:
			streamurl.append( stream1 )
			streamurl.append( stream2 )
			streamname.append( 'Stream 1' )
			streamname.append( 'Stream 2' )
			streamthumb.append( thumb )
			streamthumb.append( thumb )
			url = streamurl[0]
			iconimage = streamthumb[0]
			ok=True
			liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage); 
			liz.setInfo( type="Video", infoLabels={ "Title": name } )
			ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
			xbmc.Player().play(url, liz, False)
			return ok
			

def get_urls(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
	
def addLink1(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="icon.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
		

def addLink(name,url,mode,iconimage,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="icon.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok		
		
		
def addDir(name,url,mode,iconimage,fanart,description=''):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="icon.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)


def addDir1(name,url,mode,iconimage,fanart):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="icon.png", thumbnailImage=iconimage)
		liz.setProperty("IsPlayable","true")
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

	
		
def addDir2(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="icon.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
		

def listBasic(url,name):
        try:link = open_url(url)
        except:link = cloudflare.request(url, mobile=True)
        
        match2=re.compile('name=(.+?)\s*thumb=(.+?)\s*URL=(.+?)\n+player').findall(link)
        for name,thumb,url in match2: addLink(name,url,3004,thumb,fanart)
        url2 = "http://pastebin.com/raw/HZnipeb4"
        try:link2 = open_url(url2)
        except:link2 = cloudflare.request(url2, mobile=True)
        
        matchm=re.compile('name=(.+?)\s*thumb=(.+?)\s*URL=(.+?)\n+p').findall(link2)
        matchm2=re.compile('name=(.+?)\s*URL=(.+?)\n+p').findall(link2)
        matchm3=re.compile('name=(.+?)\s*date=(.+?)\s*URL=(.+?)\n+p').findall(link2)
        matchm4=re.compile('name=(.+?)\s*thumb=(.+?)\s*date=(.+?)\s*URL=(.+?)\n+p').findall(link2)
        for name,thumb,url in matchm:
                name=re.sub(r'\.',r' ', name)
                addLink(name,url,3004,thumb,thumb)
        for name,url in matchm2:
				addLink(name,url,3004,icon,fanart)
        for name,date,url in matchm3:
				addLink(name,url,3004,icon,fanart)
        for name,thumb,date,url in matchm4:
				addLink(name,url,3004,thumb,fanart)		


				
def listA(url,name):
        url=url.replace(' ','%20')
        try:link = open_url(url)
        except:link = cloudflare.request(url, mobile=True)
       
        match=re.compile('<link>(.+?)</link><thumbnail>(.+?)</thumbnail><title>(.+?)</title>').findall(link)
        for url,thumb,name in match:
			if "dnahost" in url:
				addDir2(name,url,3001,thumb,fanart)
			else: addLink(name,url,3004,thumb,fanart)

def listB(url,name):
	try:link = open_url(url)
	except:link = cloudflare.request(url, mobile=True)
	all_links = regex_get_all(link, '<channel>', '</channel>')
	for list in all_links:
		dir = regex_from_to(list, '<externallink>', '</externallink>')
		name = regex_from_to(list, '<name>', '</name>')
		url = regex_from_to(list, '<link>', '</link>')
		thumb = regex_from_to(list, '<thumbnail>', '</thumbnail>')
		if "ignore" in url:
			addDir2(name,dir,3002,thumb,fanart)
		
	item_links = regex_get_all(link, '<item>', '</item>')
	for list in item_links:
		name = regex_from_to(list, '<title>', '</title>')
		url = regex_from_to(list, '<link>', '</link>')
		thumb = regex_from_to(list, '<thumbnail>', '</thumbnail>')
		if url:
			if "sublink" in url:
				addDir2(name,url,3003,thumb,fanart)
			else:
				addLink(name,url,3004,thumb,fanart)
	youtube_links = regex_get_all(link, '<item>', '</item>')
	for list in youtube_links:
		name = regex_from_to(list, '<title>', '</title>')
		url = regex_from_to(list, '<utube>', '</utube>')
		url = "https://www.youtube.com/watch?v=" + url
		thumb = regex_from_to(list, '<thumbnail>', '</thumbnail>')
		if url:
			if "sublink" in url:
				addDir2(name,url,3003,thumb,fanart)
			else:
				addLink(name,url,3004,thumb,fanart)

def GetSublinks(name,url,iconimage,fanart):
    sources = []
    sname = []
    n = 0
    all_videos = regex_get_all(url, 'sublink:', '#')
    for a in all_videos:
		n = n+1
		vurl = a.replace('sublink:','').replace('#','')
		sources.append(vurl)
		sname.append(name+ ' Source ['+str(n)+']')
	
    dialog = xbmcgui.Dialog()
    index = dialog.select('Select a source:', sname)
    if index>-1:
			url=sources[index]
			try:
				from resources.lib import resolvers
				url = resolvers.request(url)
				xbmc.Player().play(url)
			except:
				try:
					resolved=urlresolver.resolve(url)
					addon.resolve_url(resolved)
				except:
					 stream_url = urlresolver.HostedMediaFile(url).resolve()
					 liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
					 xbmc.Player ().play(stream_url,liz,False)
		
			addLink('Press back to exit','',1,icon,fanart)
			
			
def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r
	

def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
	   try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
	   except: r = ''
    else:
       try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
       except: r = ''
    return r
	
	
def open_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
		
	
def playvideo(name,url):
	if ".m3u8" in url:
		get_stream(url,name)
	elif ".m3u" in url:
		get_stream(url,name)
	elif ".ly" in url:
		get_stream(url,name)
#	elif "test" in url:
#		get_stream(url,name)
#		try:link = open_url(url)
#		except:link = cloudflare.request(url, mobile=True)
#		addon.resolve_url(url)
	elif ".ts" in url:
		get_stream(url,name)
#		get_stream_dex(url,name)
	elif "rtmp://" in url:
		addon.resolve_url(url)		
	elif "onedrive" in url:
		get_stream(url,name)
	else:
		try:
			get_stream(url,name)
#			resolved=urlresolver.resolve(url)
#			addon.resolve_url(resolved)
		except: 
			try:
				stream_url = urlresolver.HostedMediaFile(url).resolve()
				liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
				xbmc.Player().play(stream_url,liz,False)
			except:
				try:
					from resources.lib import resolvers
					url = resolvers.request(url)
					get_stream(url,name)
#					addon.resolve_url(url)
				except: pass		
		addLink('Press back to exit','',1,icon,fanart)
		

def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
	

def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
	

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param
		
def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if selfAddon.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % selfAddon.getSetting(viewType) )
		

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

print "Site: "+str(site); print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)
print params


#if mode is None:start()
if mode is None:Main()
elif mode==100:bonus_streams()
elif mode==500:livetv()
elif mode==1001:dnatvguide()
elif mode==1002:get_stream(url,name)
elif mode==1003:DeleteCache(url)
elif mode==1005:CacheDel()
elif mode==2101:list_channels(1)
elif mode==2102:list_channels(2)
elif mode==2103:list_channels(3)
elif mode==2104:list_channels(4)
elif mode==2105:list_channels(5)
elif mode==2106:list_channels(6)
elif mode==2107:list_channels(7)
elif mode==2110:list_channels(10)
elif mode==3000:listBasic(url,name)
elif mode==3001:listA(url,name)
elif mode==3002:listB(url,name)
elif mode==3003:GetSublinks(name,url,iconimage,fanart)
elif mode==3004:playvideo(name,url)
elif mode==4000:guideStream(name)


	

xbmcplugin.endOfDirectory(int(sys.argv[1]))
xbmcplugin.endOfDirectory(plugin_handle)