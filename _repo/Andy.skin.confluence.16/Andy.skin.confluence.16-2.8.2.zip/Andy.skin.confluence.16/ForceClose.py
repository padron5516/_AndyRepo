import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, sys, time, xbmcvfs
import glob
import shutil
import subprocess
dialog     =  xbmcgui.Dialog()
dp         =  xbmcgui.DialogProgress()

mode='Kill_KODI'

def Kill_KODI():
    #dialog.ok('Force Close Kodi','The system will now attempt to force close Kodi.','You may encounter a freeze, if that happens give it a minute','and if it doesn\'t close please restart your system.')

    if xbmc.getCondVisibility('system.platform.windows'):
        print "############   Try Windows force close  #################"
        try: os.system('TASKKILL /im pulsar.exe /f');os.system('TASKKILL /im kodi.exe /f')
        except: pass
        try: os.system('tskill pulsar.exe');os.system('tskill Kodi.exe')
        except: pass
        
    elif xbmc.getCondVisibility('system.platform.android'):
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass

    elif xbmc.getCondVisibility('system.platform.osx'):
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
         
    elif xbmc.getCondVisibility('system.platform.linux'):
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
                
    #dialog.ok("WARNING  !!!", "If you\'re seeing this message it means the force close", "was unsuccessful. Please close Kodi via your operating system.",'')
    xbmc.executebuiltin("Quit")

if mode=='Kill_KODI' : Kill_KODI()