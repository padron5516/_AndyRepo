script.ivueguide
===============

Ivue Guide allows you to combine some of your favourite live TV plugins for use with a fully working EPG.

Based on the original TV Guide by twinther, Dixie, Bluezed, Rayw, Ivue,

**NOTE**
This TV guide has been re skinned using the original developers code all credits must go to them ie FXB78,Bluezed tommy winther dixie Ray Wilson, Ivue,