#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified for tecbox Guide (02/2015 onwards)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import gui, xbmcgui
import utils, urllib2, base64


TeamIvueMSG = 'VmVyeSBuaWNlIGNvZGUgaVZ1ZSBUZWFtLiAgSSBqdXN0IHNpbXBseSB3YW50IGEgZ3VpZGUgZm9yIGEgZmV3IGZyaWVuZHMgYW5kIGZhbWlseSB0aGF0IGtub3cgbm90aGluZyBhYm91dCBjb25maWd1cmluZyBLb2RpLiAgWW91IHNlZW1lZCB0byBvZiBhYmFuZG9uZWQgdGhpcyB2ZXJzaW9uIG9mIGNvZGUgc28gaW0gbW9kZGluZyBpdCB0byBteSB0YXN0ZS4gIEkgaW50ZW5kIHRvIGxlYXZlIHlvdXIgdmVyc2lvbiA2IGFuZCB1cCB1bnRvdWNoZWQgYXMgeW91IG9mZmVyIGFuIGludmFsdWFibGUgc2VydmljZSB0byB0aGUgY29tbXVuaXR5LiAgSSByZXNwZWN0IHlvdXIgYXV0aCBjcmVkZW50aWFscy4gIEkganVzdCBoYXBwZW4gdG8gYmUgZ29vZCBhcyByZXZlcnNlIGVuZ2luZWVyaW5nIHB5dGhvbiBhbmQgZW5jcnlwdGlvbi4gIEZlZWwgZnJlZSB0byB1c2UgbXkgc2tpbiBpZGVhcyBvciBhbnl0aGluZyBlbHNlIGluIG15IGd1aWRlLiAgSSB3aXNoIHRoZSBjb21tdW5pdHkgd2FzbnQgZmlsbGVkIHdpdGggc28gbWFueSBqYWNrYWxzLiAgSXRzIGxlZCBtZSB0byB3cml0ZSBpbiBmdWNraW5nIGVuY3J5cHRpb24gaGFoYQ=='

addon_id = base64.b64decode(b'QW5keS5wbHVnaW4ucHJvZ3JhbS5HdWlkZQ==')


try:
    w = gui.TVGuide()
    w.doModal()
    del w

except:
    import sys
    import traceback as tb
    (etype, value, traceback) = sys.exc_info()
    tb.print_exception(etype, value, traceback)
    
   
    