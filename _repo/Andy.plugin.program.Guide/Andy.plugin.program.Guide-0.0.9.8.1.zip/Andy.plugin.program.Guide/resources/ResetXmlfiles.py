import time
import os
import xbmc
import xbmcgui
import xbmcaddon




def deleteDB():
    try:
        xbmc.log("[Andy.plugin.program.Guide] Deleting guide data xml files...", xbmc.LOGDEBUG)
        dbPath1 = xbmc.translatePath(xbmcaddon.Addon(id = 'Andy.plugin.program.Guide').getAddonInfo('profile'))
        dbPath1 = os.path.join(dbPath1, 'guide.xml')

        delete_file(dbPath1)

        passed = not os.path.exists(dbPath1)

        if passed:
            xbmc.log("[Andy.plugin.program.Guide] Deleting Ivue data xml files...PASSED", xbmc.LOGDEBUG)
        else:
            xbmc.log("[Andy.plugin.program.Guide] Deleting Ivue data xml files...FAILED", xbmc.LOGDEBUG)

        return passed

    except Exception, e:
        xbmc.log('[Andy.plugin.program.Guide] Deleting Ivue data xml files...EXCEPTION', xbmc.LOGDEBUG)
        return False
		
def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1

if __name__ == '__main__':
    if deleteDB():
        d = xbmcgui.Dialog()
        d.ok('TV EPG', 'Deleting Ivue data files successfully completed.', 'It will be re-created next time you start the guide')
    else:
        d = xbmcgui.Dialog()
        d.ok('TV EPG', 'Deleting Ivue data files Failed.', 'files may be locked,', 'please restart Kodi and try again')
