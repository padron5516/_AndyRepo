# coding: UTF-8
#http://forum.kodi.tv/showthread.php?tid=259761
import sys
import xbmcgui
import xbmc
import xbmcaddon
import json
import os

ADDONID     = 'Andy.plugin.program.Guide'
ADDON       =  xbmcaddon.Addon(ADDONID)
PROFILE     =  xbmc.translatePath(ADDON.getAddonInfo('profile'))
PVRACTIVE   = (xbmc.getCondVisibility('Pvr.HasTVChannels')) or (xbmc.getCondVisibility('Pvr.HasRadioChannels')) == True
dialog = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
icon = xbmc.translatePath(os.path.join('special://home/addons', ADDONID, 'icon.png'))
mode = 'DoPVR'

def addpvrini():
    if not PVRACTIVE:
        return
    path = os.path.join(PROFILE)        
    pvrIniPath  = os.path.join(path, 'addons.ini')
        
    # Create dir  
    if not os.path.exists(path):
        os.makedirs(path)
   
    # tv
    try:
        tryTvChannels  = _getPVRChannels('"tv"')
        tryTvChannelsCommand = tryTvChannels[('result')]          
    except: pass
    
    # radio
    try:
        tryRadio  = _getPVRChannels('"radio"')
        tryRadioCommand = tryRadio[('result')]
    except: pass

    # Execute
    try:
        foundTvChannels  = tryTvChannelsCommand['channels']      
        foundRadioChannels  = tryRadioCommand['channels']
    except: pass
    
    ThePVRini  = file(pvrIniPath, 'a')
    ######################################################################################
    #ThePVRini.write('[pvr.iptvsimple]\n')    
    ThePVRini.write('[Andy.plugin.program.Guide]\n')     
   
   
    try:
        for TryToFindStreams in foundTvChannels:
            WhatsTheGroupID  = TryToFindStreams[('label')]  
            stream = ('%s') % TryToFindStreams[('channelid')]
            ThePVRini.write(('%s') % WhatsTheGroupID)
            ThePVRini.write("=")
            ThePVRini.write(('%s') % stream)            
            ThePVRini.write("\n")
    except: pass
    
    try:
        for TryToFindStreams in foundRadioChannels:          
            WhatsTheGroupID  = TryToFindStreams[('label')]  
            stream = ('%s') % TryToFindStreams[('channelid')]
            ThePVRini.write(('%s') % WhatsTheGroupID)
            ThePVRini.write("=")
            ThePVRini.write(('%s') % stream)            
            ThePVRini.write("\n")
    except: pass
    
    ThePVRini.write("\n")
    ThePVRini.close()
    
    # Notification   
    #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("PVR","M3U and addon.ini Credentials.",3000, icon))
    
def _getPVRChannels(group):   
    method   = 'PVR.GetChannels'
    params   = 'channelgroupid'
    WhatAreGroupIDs  =  getGroupID(group)
    checkPVR =  sendJSON(method, params, WhatAreGroupIDs)   
    return checkPVR

def getGroupID(group):
    method   = 'PVR.GetChannelGroups'
    params   = 'channeltype'   
    checkPVR = sendJSON(method, params, group)
    result   = checkPVR[('result')]
    groups   = result[('channelgroups')]
    #
    for group in groups:
        WhatsTheGroupID = group[('label')]
        if WhatsTheGroupID == ('All channels'):
            return group[('channelgroupid')]

def sendJSON(method, params, value):
    JSONPVR  = ('{"jsonrpc":"2.0","method":"%s","params":{"%s":%s}, "id":"1"}' % (method, params, value))    
    checkPVR = xbmc.executeJSONRPC(JSONPVR)
    return json.loads(checkPVR.decode("utf-8"),("ignore"))

if mode=='DoPVR' : addpvrini()
