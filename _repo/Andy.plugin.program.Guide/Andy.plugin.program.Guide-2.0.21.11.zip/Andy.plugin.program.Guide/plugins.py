# coding: UTF-8
import sys
l1llll11_opy_ = sys.version_info [0] == 2
l1ll11l_opy_ = 2048
l1ll1l_opy_ = 7
def l1111l_opy_ (ll_opy_):
	global l111_opy_
	l1111l1_opy_ = ord (ll_opy_ [-1])
	l1lllll1_opy_ = ll_opy_ [:-1]
	l1ll1_opy_ = l1111l1_opy_ % len (l1lllll1_opy_)
	l11l11l_opy_ = l1lllll1_opy_ [:l1ll1_opy_] + l1lllll1_opy_ [l1ll1_opy_:]
	if l1llll11_opy_:
		l1l1ll1_opy_ = unicode () .join ([unichr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l11l_opy_)])
	else:
		l1l1ll1_opy_ = str () .join ([chr (ord (char) - l1ll11l_opy_ - (l11l1l_opy_ + l1111l1_opy_) % l1ll1l_opy_) for l11l1l_opy_, char in enumerate (l11l11l_opy_)])
	return eval (l1l1ll1_opy_)
import xbmc
import xbmcaddon
import json
import os
import shutil
import dixie
l11l11lll_opy_     = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡳࡺࡶࠨम")
l11ll11ll_opy_     = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡻ࡫ࡵࡷࡵ࡯ࠬय")
l11l1l11l_opy_ = [l11l11lll_opy_, l11ll11ll_opy_]
HOME = dixie.PROFILE
PATH = os.path.join(HOME, l1111l_opy_ (u"ࠧࡪࡰ࡬ࠫर"))
def checkAddons():
    for l11l1l1_opy_ in l11l1l11l_opy_:
        if l11ll1111_opy_(l11l1l1_opy_):
            try: l1l11lll_opy_(l11l1l1_opy_)
            except: pass
def l11ll1111_opy_(l11l1l1_opy_):
    if xbmc.getCondVisibility(l1111l_opy_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠩࡸ࠯ࠧऱ") % l11l1l1_opy_) == 1:
        return True
    return False
def l1l11lll_opy_(l11l1l1_opy_):
    l1l1l11l_opy_ = l11l11ll1_opy_(l11l1l1_opy_) + l1111l_opy_ (u"ࠩ࠱࡭ࡳ࡯ࠧल")
    l1l11l1l_opy_  = os.path.join(PATH, l1l1l11l_opy_)
    l1lll11l_opy_ = l11lll11l_opy_(l11l1l1_opy_)
    l1l1ll1l_opy_  = file(l1l11l1l_opy_, l1111l_opy_ (u"ࠪࡻࠬळ"))
    l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠫࡠ࠭ऴ"))
    l1l1ll1l_opy_.write(l11l1l1_opy_)
    l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠬࡣࠧव"))
    l1l1ll1l_opy_.write(l1111l_opy_ (u"࠭࡜࡯ࠩश"))
    for channel in l1lll11l_opy_:
        l1l1lll1_opy_   = channel[l1111l_opy_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ष")]
        l1l1lll1_opy_ = l1l1lll1_opy_.replace(l1111l_opy_ (u"ࠨࠢ࡞ࠫस"), l1111l_opy_ (u"ࠩ࡞ࠫह")).replace(l1111l_opy_ (u"ࠪࡡࠥ࠭ऺ"), l1111l_opy_ (u"ࠫࡢ࠭ऻ")).replace(l1111l_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡧࡱࡶࡣࡠ़ࠫ"), l1111l_opy_ (u"࠭ࠧऽ")).replace(l1111l_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡰࡩ࡬ࡸࡥࡦࡰࡠࠫा"), l1111l_opy_ (u"ࠨࠩि")).replace(l1111l_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡼࡩࡱࡲ࡯ࡸ࡟ࠪी"), l1111l_opy_ (u"ࠪࠫु")).replace(l1111l_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࠪू"), l1111l_opy_ (u"ࠬ࠭ृ")).replace(l1111l_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࠧॄ"), l1111l_opy_ (u"ࠧࠨॅ")).replace(l1111l_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢ࠭ॆ"), l1111l_opy_ (u"ࠩࠪे")).replace(l1111l_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠪै"), l1111l_opy_ (u"ࠫࠬॉ")).replace(l1111l_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧॊ"), l1111l_opy_ (u"࠭ࠧो"))
        stream  = channel[l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࠬौ")]
        l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠨࠧࡶ्ࠫ") % l1l1lll1_opy_)
        l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠩࡀࠫॎ"))
        l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠪࠩࡸ࠭ॏ") % stream)
        l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠫࡡࡴࠧॐ"))
    l1l1ll1l_opy_.write(l1111l_opy_ (u"ࠬࡢ࡮ࠨ॑"))
    l1l1ll1l_opy_.close()
def l11l11ll1_opy_(l11l1l1_opy_):
    if l11l1l1_opy_ == l11l11lll_opy_:
        return l1111l_opy_ (u"࠭࡮ࡵࡸ॒ࠪ")
    if l11l1l1_opy_ == l11ll11ll_opy_:
        return l1111l_opy_ (u"ࠧࡶ࡭ࡷࠫ॓")
def l11lll11l_opy_(l11l1l1_opy_):
    if l11l1l1_opy_ == l11ll11ll_opy_:
        return l11l1l1ll_opy_(l11l1l1_opy_)
    if l11l1l1_opy_ == l11l11lll_opy_:
        xbmcaddon.Addon(l11l11lll_opy_).setSetting(l1111l_opy_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ॔"), l1111l_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨॕ"))
        xbmcaddon.Addon(l11l11lll_opy_).setSetting(l1111l_opy_ (u"ࠪࡸࡻ࡭ࡵࡪࡦࡨࠫॖ"), l1111l_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪॗ"))
    l11ll1ll1_opy_  = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨक़") + l11l1l1_opy_
    l11l1lll1_opy_ =  l11lll111_opy_(l11l1l1_opy_)
    query   =  l11ll1ll1_opy_ + l11l1lll1_opy_
    return sendJSON(query, l11l1l1_opy_)
def getPluginInfo(streamurl):
    if streamurl.isdigit():
        l11l1llll_opy_   = l1111l_opy_ (u"࠭ࡋࡰࡦ࡬ࠤࡕ࡜ࡒࠡࡅ࡫ࡥࡳࡴࡥ࡭ࠩख़")
        l11ll11l1_opy_ = os.path.join(dixie.RESOURCES, l1111l_opy_ (u"ࠧ࡬ࡱࡧ࡭࠲ࡶࡶࡳ࠰ࡳࡲ࡬࠭ग़"))
        return l11l1llll_opy_, l11ll11l1_opy_
    if streamurl.startswith(l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫज़")):
        name = streamurl.split(l1111l_opy_ (u"ࠩ࠲࠳ࠬड़"), 1)[-1].split(l1111l_opy_ (u"ࠪ࠳ࠬढ़"), 1)[0]
    if streamurl.startswith(l1111l_opy_ (u"ࠫࡍࡊࡔࡗ࠼ࠪफ़")):
        name = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡭ࡪࡴࡷࠩय़")
    if streamurl.startswith(l1111l_opy_ (u"࠭ࡈࡅࡖ࡙࠶࠿࠭ॠ")):
        name = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡲࡶࡻࡤ࡭ࡵࡺࡶࠨॡ")
    if streamurl.startswith(l1111l_opy_ (u"ࠨࡊࡇࡘ࡛࠹࠺ࠨॢ")):
        name = l1111l_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡴࡸࡽࡦࡺࡶࠨॣ")
    if streamurl.startswith(l1111l_opy_ (u"ࠪࡌࡉ࡚ࡖ࠵࠼ࠪ।")):
        name = l1111l_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡱ࠭॥")
    if streamurl.startswith(l1111l_opy_ (u"ࠬࡏࡐࡍࡃ࡜࠾ࠬ०")):
        name = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡨࡢࡤ࡫ࡳࡰࡦࡿࡥࡳࠩ१")
    if streamurl.startswith(l1111l_opy_ (u"ࠧࡊࡒࡏࡅ࡞࠸࠺ࠨ२")):
        name = l1111l_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡪࡲ࡯ࡥࡾ࡫ࡲࡸࡹࡺࠫ३")
    if streamurl.startswith(l1111l_opy_ (u"ࠩࡌࡔࡑࡇ࡙ࡓ࠼ࠪ४")):
        name = l1111l_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡬ࡴࡱࡧࡹࡦࡴࡺࡻࡼ࠭५")
    if streamurl.startswith(l1111l_opy_ (u"ࠫࡎࡖࡌࡂ࡛ࡌࡘ࡛ࡀࠧ६")):
        name = l1111l_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡮ࡺࡶࠨ७")
    if streamurl.startswith(l1111l_opy_ (u"࠭ࡌࡊࡘࡈࡘ࡛ࡀࠧ८")):
        name = l1111l_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴࡬ࡪࡸࡨࡱ࡮ࡾࠧ९")
    if streamurl.startswith(l1111l_opy_ (u"ࠨࡷࡳࡲࡵࡀࠧ॰")):
        name = l1111l_opy_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰࡫ࡨ࡭ࡵ࡭ࡦࡴࡸࡲ࠳ࡼࡩࡦࡹࠪॱ")
    try:
        l11l1llll_opy_   = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"ࠪࡲࡦࡳࡥࠨॲ"))
        l11ll11l1_opy_ = xbmcaddon.Addon(name).getAddonInfo(l1111l_opy_ (u"ࠫ࡮ࡩ࡯࡯ࠩॳ"))
    except:
        l11l1llll_opy_   = l1111l_opy_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡳࡵࡴࡨࡥࡲࠦ࡯ࡳࠢࡤࡨࡩ࠳࡯࡯ࠩॴ")
        l11ll11l1_opy_ =  dixie.ICON
    return l11l1llll_opy_, l11ll11l1_opy_
def l11l1l1ll_opy_(l11l1l1_opy_):
    l11ll1ll1_opy_ = l1111l_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩॵ") + l11l1l1_opy_
    l11l1l1l1_opy_ = l1111l_opy_ (u"ࠧ࠰ࡁࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠦࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࡀࠪࡲࡵࡤࡦ࠿࠴ࠪࡳࡧ࡭ࡦ࠿ࡏ࡭ࡻ࡫ࠥ࠳࠲ࡗ࡚ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࠥ࠴ࡣࠨ࠶࡫ࠫ࠲ࡧ࡯ࡨࡸࡦࡲ࡫ࡦࡶࡷࡰࡪ࠴ࡣࡰࠧ࠵ࡪ࡚ࡑࡔࡶࡴ࡮࠵࠽࠶࠲࠳࠲࠴࠺ࠪ࠸ࡦࡍ࡫ࡹࡩࠪ࠸࠵࠳࠲ࡗ࡚࠳ࡺࡸࡵࠩॶ")
    l11l1l111_opy_ = l1111l_opy_ (u"ࠨ࠱ࡂࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠧ࡫ࡦࡳࡳ࡯࡭ࡢࡩࡨࡁࠫࡳ࡯ࡥࡧࡀ࠵ࠫࡴࡡ࡮ࡧࡀࡗࡵࡵࡲࡵࡵࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࠪ࠹ࡡࠦ࠴ࡩࠩ࠷࡬࡭ࡦࡶࡤࡰࡰ࡫ࡴࡵ࡮ࡨ࠲ࡨࡵࠥ࠳ࡨࡘࡏ࡙ࡻࡲ࡬࠳࠻࠴࠷࠸࠰࠲࠸ࠨ࠶࡫࡙ࡰࡰࡴࡷࡷࡑ࡯ࡳࡵ࠰ࡷࡼࡹ࠭ॷ")
    l1lll111_opy_  = []
    l1lll111_opy_ += sendJSON(l11ll1ll1_opy_ + l11l1l1l1_opy_, l11l1l1_opy_)
    l1lll111_opy_ += sendJSON(l11ll1ll1_opy_ + l11l1l111_opy_, l11l1l1_opy_)
    return l1lll111_opy_
def l11lll111_opy_(l11l1l1_opy_):
    if l11l1l1_opy_ == l11l11lll_opy_:
        return l1111l_opy_ (u"ࠩ࠲ࡃࡨࡧࡴ࠾࠯࠵ࠪࡲࡵࡤࡦ࠿࠵ࠪࡳࡧ࡭ࡦ࠿ࡐࡽࠪ࠸࠰ࡄࡪࡤࡲࡳ࡫࡬ࡴࠨࡸࡶࡱࡃࡵࡳ࡮ࠪॸ")
def sendJSON(query, l11l1l1_opy_):
    try:
        l11lll_opy_     = l1111l_opy_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡊ࡮ࡲࡥࡴ࠰ࡊࡩࡹࡊࡩࡳࡧࡦࡸࡴࡸࡹࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠥ࠾ࠧࠫࡳࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭ॹ") % query
        l1ll111_opy_  = xbmc.executeJSONRPC(l11lll_opy_)
        response = json.loads(l1ll111_opy_)
        result   = response[l1111l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫॺ")]
        return result[l1111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡶࠫॻ")]
    except Exception as e:
        l1l11ll1_opy_(e, l11l1l1_opy_)
        return {l1111l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠬॼ") : l1111l_opy_ (u"ࠧࡑ࡮ࡸ࡫࡮ࡴࠠࡆࡴࡵࡳࡷ࠭ॽ")}
def l1l11ll1_opy_(e, l11l1l1_opy_):
    l1l1llll_opy_ = l1111l_opy_ (u"ࠨࡕࡲࡶࡷࡿࠬࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡧࡧ࠾ࠥࡐࡓࡐࡐࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠩࡸ࠲ࠠࠦࡵࠪॾ")  % (e, l11l1l1_opy_)
    l1l1l1ll_opy_ = l1111l_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡹࡸࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡦࡰࡴࡸࡱ࠳࠭ॿ")
    l1ll111l_opy_ = l1111l_opy_ (u"࡙ࠪࡵࡲ࡯ࡢࡦࠣࡥࠥࡲ࡯ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣࡥࡩࡪ࡯࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡦࡴࡤࠡࡲࡲࡷࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫࠯ࠩঀ")
    dixie.log(l11l1l1_opy_)
    dixie.log(e)
def getPlaylist():
    try:
        l11l1ll11_opy_  = l1111l_opy_ (u"ࠦࡴࡹ࠮ࡳࡧࡰࡳࡻ࡫ࠨࡰࡵ࠱ࡴࡦࡺࡨ࠯࡬ࡲ࡭ࡳ࠮ࡸࡣ࡯ࡦ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࡐࡢࡶ࡫ࠬࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡲࡵࡳ࡫࡯࡬ࡦ࠱ࠪ࠭࠱࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣ࠲ࡷࡨࡸࡩࡱࡶ࠱ࡸࡻࡶ࡯ࡳࡶࡤࡰ࠴ࡶࡲࡰࡩࡵࡥࡲ࠴ࡤࡣࠩࠬ࠭ࠧঁ")
        eval(l11l1ll11_opy_)
    except: pass
    import requests
    l11ll1l1l_opy_ = [l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡭࡯࠳࡮࠱࡭ࡳࡱ࠯࡬ࡱࡧ࡭ࠬং"), l1111l_opy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡸ࠯ࡥࡲ࠳ࡩࡨࡣࡩ࠲࠴ࠫঃ"), l1111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭࠳ࡩࡣ࡭ࡦ࠱࡭ࡴ࠭঄"), l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡬ࡳ࠳ࡩࡣ࡭ࡱࡸࡨࡹࡼ࠮ࡰࡴࡪ࠳ࡰࡵࡤࡪࠩঅ")]
    l11ll1l11_opy_ =  l1111l_opy_ (u"ࠩࠦࡉ࡝࡚ࡍ࠴ࡗࠪআ")
    for url in l11ll1l1l_opy_:
        dixie.log(url)
        try:
            request  = requests.get(url)
            l11ll111l_opy_ = request.text
        except: pass
        if l11ll1l11_opy_ in l11ll111l_opy_:
            path = os.path.join(dixie.PROFILE, l1111l_opy_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡳ࠳ࡶࠩই"))
            with open(path, l1111l_opy_ (u"ࠫࡼ࠭ঈ")) as f:
                f.write(l11ll111l_opy_)
                break
    import urllib
    l11ll1lll_opy_ = os.path.join(PATH, l1111l_opy_ (u"ࠬࡺࡥ࡮ࡲ࡬ࡲ࡮࠭উ"))
    l1l11l1l_opy_  = os.path.join(PATH, l1111l_opy_ (u"࠭ࡩ࡯࡫࠵࠲࡮ࡴࡩࠨঊ"))
    l11ll1l1l_opy_  = l1111l_opy_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡒࡦࡰࡨ࡫ࡦࡪࡥࡴࡖ࡙࠳ࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡴࡨࡲࡪ࡭ࡡࡥࡧࡶࡸࡻ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡡࡥࡦࡲࡲࡸ࠸࠮ࡪࡰ࡬ࠫঋ")
    urllib.urlretrieve(l11ll1l1l_opy_, l11ll1lll_opy_)
    temp = open(l11ll1lll_opy_)
    l11l1ll1l_opy_  = open(l1l11l1l_opy_, l1111l_opy_ (u"ࠨࡹࡷࠫঌ"))
    for line in temp:
        l11l1ll1l_opy_.write(line.replace(
                               l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡧࡩࡽࡣࠧ঍"), l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡼࡽࡾ࡝ࠨ঎"))
                               .replace(l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡋ࠴ࡔ࠯ࡘࡠࠫএ"), l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡾࡸࡹ࡟ࠪঐ"))
                               .replace(l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡩࡱ࡮ࡤࡽࡪࡸࡷࡸࡹࡠࠫ঑"), l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹࡺࡻࡡࠬ঒"))
                               .replace(l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡫ࡷࡺࡢ࠭ও"), l1111l_opy_ (u"ࠩ࡞ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡻࡼࡽࡣࠧঔ"))
                               .replace(l1111l_opy_ (u"ࠪ࡟ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡦࡧࡩࡩࡱ࡮ࡤࡽࡪࡸ࡝ࠨক"), l1111l_opy_ (u"ࠫࡠࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡽࡾࡸ࡞ࠩখ"))
                               .replace(l1111l_opy_ (u"ࠬࡡࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡩࡡࡴࡶࡤࡻࡦࡿ࡝ࠨগ"), l1111l_opy_ (u"࡛࠭ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡸࡹࡺࡠࠫঘ"))
                               .replace(l1111l_opy_ (u"ࠧ࡜ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡹ࡮ࡠࠫঙ"), l1111l_opy_ (u"ࠨ࡝ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡺࡻࡼࡢ࠭চ"))
                               )
    temp.close()
    l11l1ll1l_opy_.close()
    os.remove(l11ll1lll_opy_)