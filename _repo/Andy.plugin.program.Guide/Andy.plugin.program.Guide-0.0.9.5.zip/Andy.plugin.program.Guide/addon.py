#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import gui, xbmcgui
import utils, urllib2, base64, os


path = xbmc.translatePath( "special://temp" )
filenames = next(os.walk(path))[2]
for i in filenames:
    if ".fi" in i:
        os.remove(os.path.join(path, i))

for i in filenames:
    if ".zip" in i:
        os.remove(os.path.join(path, i))


try:
	w = gui.TVGuide()
	w.doModal()
	del w
	

except urllib2.HTTPError, e:
		if e.code == 401:
			#utils.notify(addon_id, ae)
			print 'Error cracked'
		else:
		    #utils.notify(addon_id, e)
			print 'Error OK'	