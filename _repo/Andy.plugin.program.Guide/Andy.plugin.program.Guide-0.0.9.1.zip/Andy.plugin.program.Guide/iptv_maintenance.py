#!/usr/bin/env python
#example to run   RunScript($CWD/iptv_maintenance.py, -u user, -p pass, -oiptv.m3u, -gENGLISH, -s, -c iptvsubs_channel_ids.txt)
from __future__ import unicode_literals
from collections import namedtuple
import argparse
import codecs
import sys,os,json,urllib2
#######################################
# Switch arguments  -  Bypassed later
#######################################
parser = argparse.ArgumentParser(description='Generate IPTVSubs m3u file.')
parser.add_argument('-c', dest='channel_fn', type=str, help='Output file of channel guide ids.')
parser.add_argument('-u', dest='username', type=str, required=True)
parser.add_argument('-p', dest='password', type=str, required=True)
parser.add_argument('-o', dest='output_file', type=str, required=True, help="m3u output file")
parser.add_argument('-g', dest='groups', type=str, help='Groups to include in m3u file, for example (-g ENGLISH,SPORTS). Includes all by default. m3u will have groups in same order specified.')
parser.add_argument('-s', dest='guide_sort', action='store_true', default=False, help="Put all channels with guide ids at the top")
parser.add_argument('-m', dest='map_file', type=str, help="Tab separated file containing map of channel names to guide id, for example \"TREEHOUSE HD (NA)	I80173.lab.zap2it.com\"")
parser.add_argument('--ini', dest='ini_file', type=str, help="ini output file")
parser.add_argument('--name-map', dest='namemap_file', type=str, help="Tab-separated file mapping channel names")

#parser.add_argument('-i', dest='ini_file', type=str, help="ini output file")
#parser.add_argument('-n', dest='namemap_file', type=str, help="Tab-separated file mapping channel names")
args = parser.parse_args(sys.argv[1:])
username = args.username
password = args.password
output_fn = args.output_file



#######################################
#Custom - Set  Kodi addon perameters
#######################################
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
#import xbmcvfs
import shutil
import xbmcaddon
addon = 'Andy.plugin.program.Guide';addon_name = addon
addonPath = xbmc.translatePath(os.path.join('special://home', 'addons', addon))
basePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon))
dbPath = xbmc.translatePath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
dialog = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
#
#namemap_file = addonPath+'/channel_names.txt'
#args.namemap_file = namemap_file
#

#######################################
# Main Menu - Choose Provider 
#######################################
choice = dialog.select('Choose a provider', ['Close',
                                             'General Maintenance',
                                             'ini and m3u Maintenance',
                                             'IPTVSubs subscription',
                                             'DexterTV subscription'])
if choice == 0: sys.exit(0)
#


#######################################
# General Maintenance
#######################################
if choice == 1:
    choice = dialog.select('Perform general maintenance', ['Close',
                                                           'Clean cache',
                                                           'Delete packages folder (old zips)',
                                                           'Delete Thumbnails',
                                                           'Delete textures (Database Textures13.db)',])
    if choice == 0:  sys.exit(0)
    #
    # Clean cache
    if choice == 1:
        xbmc_cache_path = xbmc.translatePath(os.path.join('special://home', 'cache'))
        if os.path.exists(xbmc_cache_path)==True:    
            for root, dirs, files in os.walk(xbmc_cache_path):
                file_count = 0
                file_count += len(files)       
                # Count files and give option to delete
                if file_count > 0:            
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
        sys.exit()
    #
    # Delete packages folder (old zips)
    if choice == 2:
        packages_cache_path = xbmc.translatePath(os.path.join('special://home/userdata', 'Thumbnails'))
        for root, dirs, files in os.walk(packages_cache_path):
           file_count = 0
           file_count += len(files)
           # Count files and give option to delete
           if file_count > 0:
               for f in files:
                   os.unlink(os.path.join(root, f))
               for d in dirs:
                   shutil.rmtree(os.path.join(root, d))
        sys.exit()
    #
    # Delete Thumbnails
    if choice == 3:
        path = xbmc.translatePath(os.path.join('special://home/userdata', 'Thumbnails'))
        dp.create(path,"Wiping...",path, 'Please Wait')
        shutil.rmtree(path, ignore_errors=True)
        sys.exit()
    #
    # Delete textures (Database Textures13.db)
    if choice == 4:
        textures = xbmc.translatePath(os.path.join('special://home/userdata/Database', 'Textures13.db'))
        try:
            dbcon = database.connect(textures)
            dbcur = dbcon.cursor()
            dbcur.execute("DROP TABLE IF EXISTS path")
            dbcur.execute("VACUUM")
            dbcon.commit()
            dbcur.execute("DROP TABLE IF EXISTS sizes")
            dbcur.execute("VACUUM")
            dbcon.commit()
            dbcur.execute("DROP TABLE IF EXISTS texture")
            dbcur.execute("VACUUM")
            dbcon.commit()
            dbcur.execute("""CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""")
            dbcon.commit()
            dbcur.execute("""CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""")
            dbcon.commit()
            dbcur.execute("""CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""")
            dbcon.commit()
        except:
            pass
        sys.exit()
#



#######################################
# ini and m3u Maintenance
#######################################
if choice == 2:
    choice = dialog.select('Choose file to edit.  Irreversible.', ['Close',
                                                                   'Copy addons.ini to addons2.ini (Create)',
                                                                   'Delete addons2.ini',
                                                                   'Delete addons.ini',
                                                                   'Delete iptv.m3u',
                                                                   'Delete iptv.m3u8',
                                                                   'Delete master.db  (Deletes linked channels)',
                                                                   'Delete guides.ini (Guide selection)',
                                                                   'Delete 0.xml      (Guide)',
                                                                   'Delete guide.xml  (Guide)',
                                                                   'View  addon2.ini',
                                                                   'View  addons.ini',
                                                                   'View  iptv.m3u8',
                                                                   'View  iptv.m3u',])
    if choice == 0:  sys.exit(0)
    #
    # Copy addons.ini to addons2.ini
    if choice == 1:
        SourceFile = os.path.join(basePath, 'addons.ini'); DestFile = os.path.join(basePath, 'addons2.ini') ; from shutil import copyfile; copyfile(SourceFile, DestFile);sys.exit()
    #
    # Delete .ini
    if choice == 2:
        filePath = os.path.join(dbPath, 'addons2.ini')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    if choice == 3:
        filePath = os.path.join(dbPath, 'addons.ini')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    if choice == 4:
        filePath = os.path.join(dbPath, 'iptv.m3u')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    if choice == 5:
        filePath = os.path.join(dbPath, 'iptv.m3u8')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    if choice == 6:
        filePath = os.path.join(dbPath, 'master.db')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    if choice == 7:
        filePath = os.path.join(dbPath, 'guides.ini')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    if choice == 8:
        filePath = os.path.join(dbPath, '0.xml')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    if choice == 9:
        filePath = os.path.join(dbPath, 'guide.xml')
        if os.path.exists(filePath):  os.remove(filePath); sys.exit()
        else: sys.exit(0)
    #
    # View files
    if choice == 10:
        filePath = os.path.join(basePath, 'addons2.ini')
        class TextBox():
         WINDOW=10147 ; CONTROL_LABEL=1 ; CONTROL_TEXTBOX=5
         def __init__(self,*args,**kwargs):  xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) ; self.win=xbmcgui.Window(self.WINDOW); xbmc.sleep(500) ; self.setControls()
         def setControls(self):
             self.win.getControl(self.CONTROL_LABEL).setLabel('View File')
             try: f=open(filePath); text=f.read()
             except: text=filePath
             self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
             return
        TextBox()
        sys.exit(0)
    #
    # View addons2.ini
    if choice == 11:
        filePath = os.path.join(basePath, 'addons.ini')
        class TextBox():
         WINDOW=10147 ; CONTROL_LABEL=1 ; CONTROL_TEXTBOX=5
         def __init__(self,*args,**kwargs):  xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) ; self.win=xbmcgui.Window(self.WINDOW); xbmc.sleep(500) ; self.setControls()
         def setControls(self):
             self.win.getControl(self.CONTROL_LABEL).setLabel('View File')
             try: f=open(filePath); text=f.read()
             except: text=filePath
             self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
             return
        TextBox()
        sys.exit(0)
    #
    # View iptv.m3u8
    if choice == 12:   
        filePath = os.path.join(basePath, 'iptv.m3u8')
        class TextBox():
         WINDOW=10147 ; CONTROL_LABEL=1 ; CONTROL_TEXTBOX=5
         def __init__(self,*args,**kwargs):  xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) ; self.win=xbmcgui.Window(self.WINDOW); xbmc.sleep(500) ; self.setControls()
         def setControls(self):
             self.win.getControl(self.CONTROL_LABEL).setLabel('View File')
             try: f=open(filePath); text=f.read()
             except: text=filePath
             self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
             return
        TextBox()
        sys.exit(0)
    #
    # View iptv.m3u
    if choice == 13:   
        filePath = os.path.join(basePath, 'iptv.m3u')
        class TextBox():
         WINDOW=10147 ; CONTROL_LABEL=1 ; CONTROL_TEXTBOX=5
         def __init__(self,*args,**kwargs):  xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) ; self.win=xbmcgui.Window(self.WINDOW); xbmc.sleep(500) ; self.setControls()
         def setControls(self):
             self.win.getControl(self.CONTROL_LABEL).setLabel('View File')
             try: f=open(filePath); text=f.read()
             except: text=filePath
             self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
             return
        TextBox()
        sys.exit(0)



#
#######################################
# Provider 1
#######################################
if choice == 3:
    provider = 'iptvsubs'
    args.groups = 'ENGLISH,SPORTS,FOR ADULTS'
    addon_name='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name);username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona');urlpath='http://2.welcm.tv'
    #choice = xbmcgui.Dialog().yesno("TV Guide  " + addon_name, "Your Username  :" + username,"Your Password  :" + password, "Cancel or OK?",  yeslabel='Yes',nolabel='No')
    #if choice == 0: sys.exit() 
    choice = dialog.select(addon_name + '  User: '+username+'  Pass: '+password, ['Close',
                                                                                  addon_name+'  -->  addons.ini',
                                                                                  addon_name+'  -->  addon2.ini',
                                                                                  addon_name+'  -->  '+provider+'.ini',
                                                                                  addon_name+'  -->  iptv.m3u8',
                                                                                  addon_name+'  -->  iptv.m3u',
                                                                                  addon_name+'  -->  '+provider+'.m3u',
                                                                                  'Copy addons.ini to addons2.ini (Create)'])                                      
    if choice == 0: sys.exit()
    if choice == 1: args.output_file='';args.ini_file='addons.ini'
    if choice == 2: args.output_file='';args.ini_file='addons2.ini'
    if choice == 3: args.output_file='';args.ini_file=provider+'.ini' ; choice = 1 # so it doesnt choose provider 2
    if choice == 4: output_fn='iptv.m3u8';args.ini_file=''
    if choice == 5: output_fn='iptv.m3u';args.ini_file=''
    if choice == 6: output_fn=provider+'.m3u';args.ini_file=''
    if choice == 7: SourceFile = os.path.join(basePath, 'addons.ini'); DestFile = os.path.join(basePath, 'addons2.ini') ; from shutil import copyfile; copyfile(SourceFile, DestFile);sys.exit()
#



#######################################
# Provider 2
#######################################
if choice == 4:
    provider = 'dex'
    args.groups = 'ENTERTAINMENT,MOVIES,UK,KIDS,NEWS,SPORTS'
    addon_name='plugin.video.dex';addon=xbmcaddon.Addon(addon_name);username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona');urlpath = addon.getSetting('lehekylg')
    #choice = xbmcgui.Dialog().yesno("TV Guide  " + addon_name, "Your Username  :" + username,"Your Password  :" + password, "Cancel or OK?",  yeslabel='Yes',nolabel='No')
    #if choice == 0: sys.exit() 
    choice = dialog.select(addon_name + '  User: '+username+'  Pass: '+password, ['Close',
                                                                                  addon_name+'  -->  addons.ini',
                                                                                  addon_name+'  -->  addon2.ini',
                                                                                  addon_name+'  -->  '+provider+'.ini',
                                                                                  addon_name+'  -->  iptv.m3u8',
                                                                                  addon_name+'  -->  iptv.m3u',
                                                                                  addon_name+'  -->  '+provider+'.m3u',
                                                                                  'Copy addons.ini to addons2.ini (Create)'])    
    if choice == 0: sys.exit()
    if choice == 1: args.output_file='';args.ini_file='addons.ini'
    if choice == 2: args.output_file='';args.ini_file='addons2.ini'
    if choice == 3: args.output_file='';args.ini_file=provider+'.ini' ; choice = 1 # so it doesnt choose provider 2
    if choice == 4: output_fn='iptv.m3u8';args.ini_file=''
    if choice == 5: output_fn='iptv.m3u';args.ini_file=''
    if choice == 6: output_fn=provider+'.m3u';args.ini_file=''
    if choice == 7: SourceFile = os.path.join(basePath, 'addons.ini'); DestFile = os.path.join(basePath, 'addons2.ini') ; from shutil import copyfile; copyfile(SourceFile, DestFile);sys.exit()
#




#
#######################################
# Run scraper
#######################################
# Last change message with credentials
choice = xbmcgui.Dialog().yesno("TV Guide  " + addon_name, "Your Username  :" + username,"Your Password  :" + password, "Cancel or OK?",  yeslabel='Yes',nolabel='No')
if choice == 0:  sys.exit(0)
# Append or write
if choice == 1:
    choice = xbmcgui.Dialog().yesno("TV Guide  " + addon_name, "Yes to Append to file, No to overwrite","Append adds to existing file." ,"No overwrites all data", yeslabel='Yes',nolabel='No')
    if choice == 1:  write_style = 'a'
    else:  write_style = 'w'
#


# Final settings before run
panel_url = urlpath+":8000/panel_api.php?username={}&password={}".format(username, password)
u = urllib2.urlopen(panel_url)
j = json.loads(u.read())


# Channel ID Map
my_map = {"TREEHOUSE HD (NA)":"I80173.labs.zap2it.com",
          "YTV HD (NA)":"I70827.labs.zap2it.com",
          "NICKELODEON HD (NA)":"I59432.labs.zap2it.com",
          "FAMILY HD (NA)":"I70520.labs.zap2it.com",
          "DISNEY XD HD (NA)":"I97315.labs.zap2it.com",
          "CARTOON NETWORK HD (NA)":"I60048.labs.zap2it.com",
          "BBC Four HD":"I116.hkrr.metabroadcast.com",
          "BBC NEWS":"I503.hkrs.metabroadcast.com",
          "BBC One HD":"I141.hkqz.metabroadcast.com",
          "BBC Two HD":"I142.hn2v.metabroadcast.com",
          "RETRO TV":"I65791.labs.zap2it.com",
          "SKY DISNEY JR (UK)":"I628.hn4d.metabroadcast.com",
          "SKY NEWS HD":"I516.hkyj.metabroadcast.com",
          "SKY NICK (UK)":"I632.hnx4.metabroadcast.com",
          "SKY NICK JR (UK)":"I615.hkz5.metabroadcast.com",
          "SKY NICK TOONS (UK)":"I606.hk4g.metabroadcast.com",
          "Sky Alibi":"I247.hn2c.metabroadcast.com",
          "Sky Animal Planet":"I562.hm6y.metabroadcast.com",
          "Sky Channel 4":"I227.hkwy.metabroadcast.com",
          "Sky Channel 5":"I105.hkvk.metabroadcast.com",
          "Sky Dave":"I246.hm4r.metabroadcast.com",
          "Sky Discovery":"I561.hk6k.metabroadcast.com",
          "Sky Discovery History":"I535.hkys.metabroadcast.com",
          "Sky Discovery Science":"I525.hkyv.metabroadcast.com",
          "Sky Discovery Shed":"I242.hk54.metabroadcast.com",
          "Sky Discovery investigation":"I522.hk9d.metabroadcast.com",
          "Sky Film 4":"I315.hkvd.metabroadcast.com",
          "Sky Gold":"I0121.hmsy.metabroadcast.com",
          "Sky Home":"I196.hkx4.metabroadcast.com",
          "Sky Movie Romance":"I310.hk7h.metabroadcast.com",
          "Sky Movies Action":"I307.hk7c.metabroadcast.com",
          "Sky Movies Comedy":"I308.hk69.metabroadcast.com",
          "Sky Movies Disney":"I305.hn2x.metabroadcast.com",
          "Sky Movies Family":"I306.hk7f.metabroadcast.com",
          "Sky Movies Premiere":"I301.hk66.metabroadcast.com",
          "Sky Movies Sci-Fi":"I311.hk7k.metabroadcast.com",
          "Sky Natgeo":"I543.hk6m.metabroadcast.com",
          "Sky Yesterday":"I537.hk4k.metabroadcast.com",
          "Sky itv1":"I103.hkvt.metabroadcast.com",
          "Sky itv2":"I118.hkwh.metabroadcast.com",
          "Sky itv3":"I119.hkwk.metabroadcast.com",
          "Sky itv4":"I120.hkwn.metabroadcast.com"
          }

if args.map_file:
  with open(args.map_file) as f:
    for line in f:
      sp_line = line.rstrip(os.linesep).split("\t")
      my_map[sp_line[0]] = sp_line[1]


channelname_map = {"A+E HD":"A&E",
                   "A&E HD":"A&E",
                   "5 Star":"5Star",
                   "5*":"5Star",
                   "ACTION HD":"ACTION",                   
                   "Alibi SD":"Alibi",      
                   "AMC HD from BT":"AMC UK",                   
                   "ANIMAL PLANET HD - NEW":"Animal Planet",             
                   "Animal Planet HD":"Animal Planet",        
                   "BBC AMERICA HD":"BBC America",  
                   "BBC One HD":"BBC ONE",        
                   "BBC One=":"BBC ONE=",                   
                   "BBC Two HD":"BBC TWO",      
                   "BBC Two":"BBC TWO", 
                   "BBC Three HD":"BBC THREE",              
                   "BBC Three":"BBC THREE",                                 
                   "BBC Four HD":"BBC FOUR",
                   "BBC Four":"BBC FOUR",
                   "BBC News Channel":"BBC News",                
                   "BBC NEWS":"BBC News",       
                   "BEINS1":"BEIN Sports 1",  
                   "BEIN HD":"BEIN Sports 1",   
                   "BET HD":"BET",        
                   "Big Ten Network HD":"Big Ten Network",                   
                   "BoxNation":"Box Nation",      
                   "BRAVO HD":"Bravo",                    
                   "BT Sport 1HD":"BT Sport 1",
                   "BT SPort 1":"BT Sport 1", 
                   "BT SPort 2":"BT Sport 2",                        
                   "CARTOON NETWORK HD (NA)":"Cartoon Network",        
                   "Cartoon Network HD":"Cartoon Network",                   
                   "CARTOON NETWORK":"Cartoon Network",      
                   "CBC EAST HD":"CBC",                    
                   "CBC NEWS HD":"CBC News",              
                   "CBS NEWS HD":"CBS News",        
                   "CBS SPORTS HD":"CBS Sports Network",                   
                   "CBS Sports=":"CBS Sports Network=",      
                   "CHCH HD":"CHCH",                    
                   "CITY TV HD":"City TV Toronto",              
                   "CNBC HD":"CNBC",        
                   "CNBC uk":"CNBC UK",                   
                   "CNN HD":"CNN",
                   "Comedy Central HD":"Comedy Central",      
                   "Comedy Central uk":"Comedy Central UK",                    
                   "COMEDY NETWORK HD":"COMEDY NETWORK",              
                   "Cooking Channel HD":"Cooking Channel",        
                   "CP24 HD":"CP24",                   
                   "Crime & Investigation":"Crime Investigation",      
                   "CTV EAST HD":"CTV Toronto",                    
                   "CTV=":"CTV Toronto=",              
                   "CW HD":"CW",        
                   "CW11 HD":"CW",                   
                   "DISCOVERY HD":"Discovery Channel",      
                   "Discovery uk":"Discovery UK",
                   "Discovery investigation":"Discovery Investigation",          
                   "Disney HD East - NEW":"Disney Channel",              
                   "Disney Jr. UK":"Disney Jr UK",        
                   "DISNEY XD HD (NA)":"Disney XD",                   
                   "DIY HD":"DIY",                      
                   "E! HD":"E!",      
                   "ESPN 2 HD":"ESPN2",                    
                   "ESPN HD":"ESPN",              
                   "Esquire Network HD":"Esquire Network",        
                   "FAMILY HD (NA)":"FAMILY",                   
                   "FOOD HD":"Food Network",      
                   "Food Network HD":"Food Network",                    
                   "FOX NEWS HD":"FOX News",
                   "FOX SPORTS 1 HD":"Fox Sports 1",        
                   "FOX SPORTS 2 HD":"Fox Sports 2",   
                   "Fox Sports 1 HD":"Fox Sports 1",        
                   "Fox Sports 2 HD":"Fox Sports 2",                   
                   "Fox UK":"FOX UK",      
                   "FX HD":"FX",                    
                   "FXX HD":"FXX",              
                   "GLOBAL EAST HD":"Global Toronto",        
                   "GLOBAL TV":"Global Toronto",                   
                   "GOLF HD":"The Golf Channel",                       
                   "GSN HD":"GSN",                   
                   "Hallmark HD":"Hallmark",      
                   "HBO COMEDY HD":"HBO Comedy",                    
                   "HBO EAST HD":"HBO HD",              
                   "HBO SIGNATURE HD":"HBO Signature",        
                   "HGTV HD":"HGTV",                   
                   "History 2":"H2USA",      
                   "HISTORY HD":"History",                    
                   "HUSTLER HD":"HUSTLER",
                   "ID HD":"ID",
                   "IFC HD":"IFC",        
                   "ITV2":"ITV 2",                   
                   "LIFE HD":"Lifetime",                       
                   "LIFETIME MOVIES HD":"LMN",                   
                   "MSNBC HD - NEW":"MSNBC",      
                   "MTV HD":"MTV",                    
                   "MTV1 UK":"MTV UK",              
                   "NAT GEO HD":"National Geographic",        
                   "NAT GEO WILD HD":"Nat Geo Wild",                   
                   "NBA HD":"NBA TV",      
                   "NBC SPORTS":"NBCSN",                    
                   "NBCSN HD":"NBCSN",              
                   "NFL NOW HD":"NFL Network",        
                   "NHL NETWORK HD":"NHL Network",                   
                   "Nick HD":"Nickelodeon",                       
                   "Nick Jr.":"Nick Jr",        
                   "NICKELODEON HD (NA)":"Nickelodeon",                   
                   "OMNI 1 HD":"OMNI 1",                       
                   "OMNI 2 HD":"OMNI 2",                   
                   "OWN HD":"OWN",      
                   "PBS HD":"PBS",                    
                   "PLAYBOY TV HD - NEW":"PLAYBOY",              
                   "Poker Central HD":"Poker Central",        
                   "PREMIER HD":"BBC ONE",                   
                   "PREMIER SPORTS":"Premiere Sports",      
                   "SHOWCASE HD - NEW":"SHOWCASE",                    
                   "SHOWTIME EAST":"Showtime HD",              
                   "SHOWTIME SHOWCASE HD":"Showtime Showcase",        
                   "SKY Box Nation":"Box Nation",                   
                   "Sky Box Office 1":"Sky Box Office",                               
                   "SKY BT 1":"BT Sport 1",        
                   "SKY BT 2":"BT Sport 2",                   
                   "Sky Channel 4":"Channel 4",                       
                   "Sky Channel 5":"Channel 5",                   
                   "SKY CHELSEA TV":"CHELSEA TV",      
                   "Sky Dave":"Dave",                    
                   "Sky Discovery History":"Discovery History",              
                   "Sky Discovery investigation":"Discovery investigation",        
                   "Sky Discovery Science":"Discovery Science",                   
                   "Sky Discovery Shed":"Discovery Shed",      
                   "Sky Discovery":"Discovery UK",                    
                   "SKY DISNEY JR (UK)":"Disney Jr UK",              
                   "SKY DISNEY XD (UK)":"Disney XD",        
                   "Sky Film 4":"Film4",                   
                   "Sky Gold":"Gold",                    
                   "Sky Home":"Home",                   
                   "Sky itv1":"ITV",      
                   "Sky itv2":"ITV 2",                    
                   "Sky itv3":"ITV3",              
                   "Sky itv4":"ITV4",        
                   "Sky Movie Romance":"SKY Romance",                   
                   "Sky Movies Action & Adventure":"SKY Action & Adventure",                               
                   "Sky Movies Action":"SKY Action & Adventure",        
                   "Sky Movies Comedy:":"SKY Comedy",                   
                   "Sky Movies Crime & Thriller":"Sky Crime & Thriller",                       
                   "Sky Movies Disney":"SKY Disney",                   
                   "Sky Movies Drama & Romance":"SKY Drama & Romance",      
                   "Sky Movies Family":"SKY Family",                    
                   "Sky Movies Premiere":"SKY Premiere",              
                   "Sky Movies Sci-Fi":"SKY Sci-Fi",        
                   "Sky Movies Select":"SKY Select",                   
                   "Sky Movies Showcase":"SKY Showcase",      
                   "Sky Movies Superheroes":"SKY Superheroes",                    
                   "SKY MUTV":"MUTV",              
                   "Sky Natgeo":"National Geographic",        
                   "SKY NEWS HD":"SKY News",                   
                   "SKY NICK (UK)":"Nickelodeon UK",                    
                   "SKY NICK TOONS (UK)":"Nick Toons UK",                   
                   "Sky RTE 1":"RTE 1",      
                   "Sky RTE 2":"RTE 2",                    
                   "SKY SPORTS 1 HD":"SKY Sports 1", 
                   "SKY SPORTS 2 HD":"SKY Sports 2",    
                   "SKY SPORTS 3 HD":"SKY Sports 3",                       
                   "SKY SPORTS 4 HD":"SKY Sports 4",                       
                   "SKY SPORTS 5 HD":"SKY Sports 5",                                
                   "Sky Sports News HD":"Sky Sports News",        
                   "Sky Yesterday":"Yesterday",                   
                   "SLICE HD":"SLICE",                               
                   "SONY ESPN HD - LIVE EVENTS":"PPV2",        
                   "Sony Six HD":"Sony Six",                   
                   "Spike HD":"Spike",
                   "SPIKE HD":"Spike",           
                   "SPORTSNET 360":"Sportsnet 360",                   
                   "SPORTSNET ONE HD":"Sportsnet ONE",      
                   "SPORTSNET ONT":"Sportsnet Ontario",                    
                   "SPORTSNET WORLD HD":"Sportsnet World",              
                   "Starz Black HD - NEW":"Starz In Black",        
                   "Starz Edge HD - NEW":"Starz Edge",                   
                   "Starz HD - NEW":"Starz",      
                   "SUNDANCE HD":"SUNDANCE",                    
                   "SyFy HD":"Syfy",              
                   "TBS HD":"TBS",        
                   "TCM EAST HD":"TCM",                   
                   "TCM HD - NEW":"TCM",                    
                   "Ten Sports HD":"Ten Sports",                   
                   "TENNIS HD":"Tennis Channel",      
                   "The Weather Channel USA":"The Weather Channel",                    
                   "TLC HD":"TLC",              
                   "TNT HD":"TNT",        
                   "TRAVEL HD":"Travel Channel",                   
                   "TRAVEL XP HD":"Travel XP",      
                   "TREEHOUSE HD (NA)":"TREEHOUSE",                    
                   "TRU TV HD":"truTV",              
                   "TruTV HD":"truTV",        
                   "TSN 1 HD":"TSN 1",                   
                   "TSN 2 HD":"TSN 2",                                     
                   "TSN 3 HD":"TSN 3",                    
                   "TSN 4 HD":"TSN 4",   
                   "TSN 5 HD":"TSN 5",                     
                   "TSN1":"TSN 1",                   
                   "TSN2":"TSN 2",                                     
                   "TSN3":"TSN 3",                    
                   "TSN4":"TSN 4",   
                   "TSN5":"TSN 5",            
                   "TV LAND HD":"TV Land",        
                   "TVO HD (NA)":"TVO",                   
                   "USA HD":"USA Network",      
                   "USA Network HD":"USA Network",                    
                   "Velocity HD - NEW":"Velocity",              
                   "VEVO 1 HD":"Vevo 1",        
                   "VEVO 2 HD":"Vevo 2",                   
                   "VEVO 3 HD":"Vevo 3",                    
                   "VH1 Classics":"VH1 Classic",                                   
                   "VH1 HD":"VH1",                   
                   "VICELAND HD":"VICELAND",      
                   "VIVID TV - NEW":"VIVID",                    
                   "W MOVIES HD - NEW":"W MOVIES",              
                   "W NETWORK HD - NEW":"W NETWORK",        
                   "WE TV HD":"WE TV",                   
                   "WEATHER CANADA HD":"WEATHER CANADA",      
                   "WWE HD":"WWE Network",                    
                   "WWE NETWORK HD":"WWE Network",              
                   "YANKEES HD - NEW":"YANKEES",                      
                   "YTV HD (NA)":"YTV"  
                  }
#channelname_map = {}
if args.namemap_file:
  with open(args.namemap_file) as f:
    for line in f:
      sp_line = line.rstrip(os.linesep).split("\t")
      channelname_map[sp_line[0]] = sp_line[1]

inv_map = {v: k for k, v in my_map.items()}

Channel = namedtuple('Channel', ['tvg_id', 'tvg_name', 'tvg_logo', 'group_title', 'channel_url'])
channels = []

online_groups = set()

for ts_id, info in j["available_channels"].iteritems():
  #channel_url = "http://2.welcm.tv:8000/live/{}/{}/{}.m3u8".format(username, password, ts_id)
  channel_url = urlpath+":8000/live/{}/{}/{}.m3u8".format(username, password, ts_id)
  tvg_id = ""
  tvg_name = info['name']
  if info['epg_channel_id'] and info['epg_channel_id'].endswith(".com"):
    tvg_id = info['epg_channel_id']
  if tvg_name in my_map:
    tvg_id = my_map[tvg_name]
  tvg_logo = ""
  #if info['stream_icon']:
  #  tvg_logo = info['stream_icon']
  group_title = info['category_name']
  online_groups.add(group_title)
  if tvg_name in channelname_map:
    tvg_name = channelname_map[tvg_name]
  channels.append(Channel(tvg_id, tvg_name, tvg_logo, group_title, channel_url))

wanted_groups = sorted(online_groups)
if args.groups:
  wanted_groups = args.groups.split(',')
group_idx = {group:idx for idx,group in enumerate(wanted_groups)}
# Has error if channel listings is different 
#sys.stderr.write("Channel groups: {}\n".format(",".join(wanted_groups)))
wanted_channels = [c for c in channels if c.group_title in wanted_groups]

if args.guide_sort:
  wanted_channels.sort(key=lambda c: "{}-{}-{}".format(0 if c.tvg_id.endswith(".com") else 1, group_idx[c.group_title], c.tvg_name))
else:
  wanted_channels.sort(key=lambda c: "{}-{}".format(group_idx[c.group_title], c.tvg_name))


if args.channel_fn:
  #with open(args.channel_fn, 'w') as channel_f:
  with open(args.channel_fn, write_style) as channel_f:
    for c in wanted_channels:
      if c.tvg_id.endswith(".com"):
        if c.tvg_name in inv_map:
          channel_f.write("{}\n".format(inv_map[c.tvg_name]))
        else:
          channel_f.write("{}\n".format(c.tvg_id))


#  append to addon.ini
if args.ini_file:
  #args.ini_file = output_fn
  #with open(args.ini_file, "w") as f:
  #with open(dbPath + args.ini_file, "a") as f:
  with open(dbPath + args.ini_file, write_style) as f:
  #with open(dbPath + output_fn, write_style) as f:
    f.write("["+addon_name+"]\n")
    for c in wanted_channels:
      f.write('{1}={4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
    sys.exit()


# append to iptv.m3u8
#with codecs.open(output_fn, "w", 'utf-8') as f:
#with codecs.open(dbPath + output_fn, "a", 'utf-8') as f:
with codecs.open(dbPath + output_fn, write_style, 'utf-8') as f:
  f.write("#EXTM3U\n")
  for c in wanted_channels:
    f.write('#EXTINF:-1 tvg-id="{0}" tvg-name="{1}" tvg-logo="{2}" group-title="{3}",{1}\n{4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
#
# append to addon.ini
#with codecs.open(dbPath + 'addons2.ini', write_style, 'utf-8') as f:
#  f.write("["+addon_name+"]\n")
#  for c in wanted_channels:
#    f.write('{1}={4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url)) 



