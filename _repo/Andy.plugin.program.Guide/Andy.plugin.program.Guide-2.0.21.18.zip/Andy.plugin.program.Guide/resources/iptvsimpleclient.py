import xbmcplugin,xbmcaddon
import time
import datetime
import xbmc
import os
#import urllib2,json
#import zipfile
#from collections import namedtuple
#from shutil import copyfile
#import traceback


class pvrUpdater:
    def __init__(self):
        updater_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/Andy.plugin.program.Guide')
        if not os.path.isdir(updater_path):
          try:
            os.mkdir(updater_path)
          except:
            pass

        try:
          self.iptvsubs_addon = xbmcaddon.Addon('plugin.video.iptvsubs')
        except:
          self.iptvsubs_addon = None
        try:
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          self.pvriptvsimple_addon = None
          
        self.checkAndUpdatePVRIPTVSetting("epgCache", "false")
        self.checkAndUpdatePVRIPTVSetting("epgPathType", "0")
        self.checkAndUpdatePVRIPTVSetting("epgPath", updater_path + '/guide.xml')
        self.checkAndUpdatePVRIPTVSetting("m3uPathType", "0")
        self.checkAndUpdatePVRIPTVSetting("m3uPath", "{0}/iptvsubs.m3u".format(updater_path))
        
        import xbmcgui
        icon=os.path.join(xbmc.translatePath('special://home'), 'addons/Andy.plugin.program.Guide/icon.png')
        dialog = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("pvr.iptvsimple","M3U and xml added to settings.xml.",3000, icon))


    def checkAndUpdatePVRIPTVSetting(self, setting, value):
      if self.pvriptvsimple_addon.getSetting(setting) != value:
        self.pvriptvsimple_addon.setSetting(setting, value)          
          
    def getSetting(name):
        return __addon__.getSetting(name)          

if __name__ == "__main__":
  epg_updater = pvrUpdater()
