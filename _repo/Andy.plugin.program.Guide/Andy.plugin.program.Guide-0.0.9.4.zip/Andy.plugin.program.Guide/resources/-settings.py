import xbmcgui, utils
import base64


addon_id = 'Andy.plugin.program.Guide'
dlg = xbmcgui.Dialog()


def showTOS():
	tos = utils.get_setting(addon_id,'tos')== "true"
#	if tos == False:
#		utils.set_setting(addon_id, 'tos', 'true')
#		dlg.ok('TV Guide TOS','By using TV Guide you agree with watching TV')

def setSettings(username,password,userid):
       username = utils.set_setting(addon_id, 'username', username)
       password = utils.set_setting(addon_id, 'password', password)
       userid = utils.set_setting(addon_id, 'userid', userid)

def setUrl():
       MAIN_URL = base64.decodestring(b'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3RoaXNtdXN0YmV0aGVwbGFjZS9fL21hc3Rlci8=')
       user = utils.set_setting(addon_id, 'userurl', MAIN_URL) 
       url = utils.set_setting(addon_id, 'mainurl', MAIN_URL)
       logos = utils.set_setting(addon_id, 'logos', MAIN_URL + 'logos/')	

	   
def checkSettings():
        username = utils.get_setting(addon_id,'username')
        password = utils.get_setting(addon_id,'password')
        userid = utils.get_setting(addon_id,'userid')
        if not username:
                retval = dlg.input('Enter TV Guide Username', type=xbmcgui.INPUT_ALPHANUM)
                if retval and len(retval) > 0:
                        utils.set_setting(addon_id, 'username', str(retval))
                        username = utils.get_setting(addon_id, 'username')
        
        if not password:
                retval = dlg.input('Enter TV Guide Password', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if retval and len(retval) > 0:
                        utils.set_setting(addon_id, 'password', str(retval))
                        password = utils.get_setting(addon_id, 'password')
		
        if not userid:
                retval = dlg.input('Enter TV Guide UserID', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if retval and len(retval) > 0:
                        utils.set_setting(addon_id, 'userid', str(retval))
                        userid = utils.get_setting(addon_id, 'userid')

