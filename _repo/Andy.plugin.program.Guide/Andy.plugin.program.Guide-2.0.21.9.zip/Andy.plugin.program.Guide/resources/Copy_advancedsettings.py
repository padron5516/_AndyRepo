import time
import os
import xbmc
import xbmcgui
import xbmcaddon

Source_maintenance = xbmc.translatePath(os.path.join('special://home', 'addons', 'Andy.plugin.program.Guide', 'resources', 'advancedsettings.xml'))
#basePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'Andy.plugin.program.Guide'))
basePath = xbmc.translatePath(os.path.join('special://home', 'userdata'))
DestFile = os.path.join(basePath, 'advancedsettings.xml')

if not os.path.exists(DestFile): 
    from shutil import copyfile;copyfile(Source_maintenance, DestFile)
    
    if os.path.exists(DestFile):   
          d = xbmcgui.Dialog()
          d.ok('TV Guide', 'Copy successfully completed.', 'It will be used next time you start Kodi')  
    
    
    