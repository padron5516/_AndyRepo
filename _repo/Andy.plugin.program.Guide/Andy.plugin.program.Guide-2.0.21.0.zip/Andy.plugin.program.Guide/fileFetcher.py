# -*- coding: utf-8 -*-
#
# FTV Guide
# Copyright (C) 2015 Thomas Geppert [bluezed]
# bluezed.apps@gmail.com
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import xbmcvfs
import os
import urllib2
import datetime
import zlib




MAIN_URL = 'https://raw.githubusercontent.com/halikus/_AndyRepo/master/_epg/'

class FileFetcher(object):
    INTERVAL_ALWAYS = 0
    INTERVAL_12 = 1
    INTERVAL_24 = 2
    INTERVAL_48 = 3

    FETCH_ERROR = -1
    FETCH_NOT_NEEDED = 0
    FETCH_OK = 1

    TYPE_DEFAULT = 1
    TYPE_REMOTE = 2

    basePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'Andy.plugin.program.Guide'))
    filePath = ''
    fileUrl = ''
    addon = None
    fileType = TYPE_DEFAULT

    def __init__(self, fileName, addon):
        self.addon = addon

        if fileName.startswith("http://") or fileName.startswith("sftp://") or fileName.startswith("ftp://") or \
                fileName.startswith("https://") or fileName.startswith("ftps://") or fileName.startswith("smb://") or \
                fileName.startswith("nfs://"):
            self.fileType = self.TYPE_REMOTE
            self.fileUrl = fileName
            self.filePath = os.path.join(self.basePath, fileName.split('/')[-1])
        else:
            self.fileType = self.TYPE_DEFAULT
            #self.fileUrl = MAIN_URL + fileName
            self.fileUrl = MAIN_URL + 'guide.zip'
            self.filePath = os.path.join(self.basePath, fileName)

        # make sure the folder is actually there already!
        if not os.path.exists(self.basePath):
            os.makedirs(self.basePath)

    def fetchFile(self):
        retVal = self.FETCH_NOT_NEEDED
        fetch = False
        if not os.path.exists(self.filePath):  # always fetch if file doesn't exist!
            fetch = True
        else:
            interval = int(self.addon.getSetting('xmltv.interval'))
            if interval != self.INTERVAL_ALWAYS:
                modTime = datetime.datetime.fromtimestamp(os.path.getmtime(self.filePath))
                td = datetime.datetime.now() - modTime
                # need to do it this way cause Android doesn't support .total_seconds() :(
                diff = (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10 ** 6) / 10 ** 6
                #if ((interval == self.INTERVAL_12 and diff >= 43200) or
                # 12 hours is actually 7 days
                #if ((interval == self.INTERVAL_12 and diff >= 604800) or     
                # 12 hours is actually 4 days
                if ((interval == self.INTERVAL_12 and diff >= 345600) or      
                        (interval == self.INTERVAL_24 and diff >= 86400) or
                        (interval == self.INTERVAL_48 and diff >= 172800)):
                    fetch = True
            else:
                fetch = True

        if fetch:      
            #tmpFile = os.path.join(self.basePath, 'tmp')
            #tmpFile = os.path.join(self.basePath, 'guide.zip')
                        
            tmpFilePath = xbmc.translatePath(os.path.join('special://addons', 'packages'))
            #tmpFilePath = xbmc.translatePath(os.path.join('special://temp'))
            tmpFile = os.path.join(tmpFilePath, 'guide.zip')

            
            if self.fileType == self.TYPE_REMOTE:
                xbmc.log('[Andy.plugin.program.Guide] file is in remote location: %s' % self.fileUrl, xbmc.LOGDEBUG)
                if not xbmcvfs.copy(self.fileUrl, tmpFile):
                    xbmc.log('[Andy.plugin.program.Guide] Remote file couldn\'t be copied: %s' % self.fileUrl, xbmc.LOGERROR)
            else:
                f = open(tmpFile, 'wb')
                xbmc.log('[Andy.plugin.program.Guide] file is on the internet: %s' % self.fileUrl, xbmc.LOGDEBUG)
                tmpData = urllib2.urlopen(self.fileUrl)
                data = tmpData.read()
                if tmpData.info().get('content-encoding') == 'gzip':
                    data = zlib.decompress(data, zlib.MAX_WBITS + 16)
                f.write(data)
                f.close()
            if os.path.getsize(tmpFile) > 256:
                if os.path.exists(self.filePath):
                    os.remove(self.filePath)
                #os.rename(tmpFile, self.filePath)
                try:
                    import zipfile                  
                    zin = zipfile.ZipFile(tmpFile, 'r')
                    zin.extractall(self.basePath)
                    #os.remove(tmpFile)
                except Exception, e:
                    print str(e)
                    return False
                return True               
                
                
                
                retVal = self.FETCH_OK
                xbmc.log('[Andy.plugin.program.Guide] file %s was downloaded' % self.filePath, xbmc.LOGDEBUG)
            else:
                retVal = self.FETCH_ERROR
        return retVal
     

        #Copy iptv_maintenance.py so you can add custom providers and not have it overwritten with an update
        Source_maintenance = xbmc.translatePath(os.path.join('special://home', 'addons', Addon, 'resources', 'iptv_maintenance.py'))
        DestFile = os.path.join(self.basePath, 'iptv_maintenance.py')
        if not os.path.exists(DestFile): 
            from shutil import copyfile;copyfile(Source_maintenance, DestFile)
        
    
        
        '''
        #GRAB POSSIBLE CREDENTIALS

        #Get iptvsubs Pass and put it in addons.ini and therefore addons2.ini assuming you have the plugin installed with the credentials entered and are doing a fresh database download in my guide
        addonPath1 = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.iptvsubs'))
        addonDestFile1 = os.path.join(addonPath1, 'settings.xml')

        if os.path.exists(addonDestFile1):
            username1=addon.getSetting('kasutajanimi')
            password1=addon.getSetting('salasona')
            finalstring = username1+'/'+password1
            
            addonini=xbmc.translatePath(self.basePath+'/addons.ini')          
            s=open(addonini).read().replace('iptvsubsemail@gmail.com',finalstring) 
            #s=s.replace('iptvsubsemail@gmail.com', username1)
            #s=s.replace('iptvsubspass', password1)
            
            addonini2 = os.path.join(self.basePath, '_addons.ini')
            a=open(addonini2,"a")
            a.write('[plugin.video.playlistLoader]') 
            a.write(s)
            a.close()  
        '''













        '''
        #Get DexterTV Pass
        addonPath2 = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.dex'))
        addonDestFile2 = os.path.join(addonPath2, 'settings.xml')
        if os.path.exists(addonDestFile2):
            Name2="DexterTV";addon_name2='plugin.video.dex';addon=xbmcaddon.Addon(addon_name2);urlpath22 = addon.getSetting('lehekylg');urlpath2=urlpath22+':8000';username2=addon.getSetting('kasutajanimi');password2=addon.getSetting('salasona');groups2 = 'ENTERTAINMENT,MOVIES,UK,KIDS,NEWS,SPORTS'
        '''
 
 
        
        
        '''        
        # Get Zip
        #Working
        if fetch:
            import zipfile
            #tmpFilePath = xbmc.translatePath(os.path.join('special://addons', 'packages'))
            tmpFilePath = xbmc.translatePath(os.path.join('special://temp'))
            tmpFile = os.path.join(tmpFilePath, 'guide.zip')
            #tmpFile = os.path.join(self.basePath, 'guide.zip')
            f = open(tmpFile, 'wb')
            self.fileUrl = MAIN_URL + 'guide.zip'
            tmpData = urllib2.urlopen(self.fileUrl)
            data = tmpData.read()
            if tmpData.info().get('content-encoding') == 'gzip':
                data = zlib.decompress(data, zlib.MAX_WBITS + 16)
            f.write(data)
            f.close()
            
            if os.path.getsize(tmpFile) > 256:
                if os.path.exists(self.filePath):
                    os.remove(self.filePath)
                try:
                    zin = zipfile.ZipFile(tmpFile, 'r')
                    zin.extractall(self.basePath)
                    #os.remove(tmpFile)
                except Exception, e:
                    print str(e)
                    return False
                return True
                
                self.filePath = os.path.join(self.basePath, fileName)
                retVal = self.FETCH_OK
                xbmc.log('[Andy.plugin.program.Guide] file %s was downloaded' % self.filePath, xbmc.LOGDEBUG)
            else:
                retVal = self.FETCH_ERROR
                
        #Source_maintenance = xbmc.translatePath(os.path.join('special://home', 'addons', Addon, 'resources', 'iptv_maintenance.py'))
        #DestFile = os.path.join(self.basePath, 'iptv_maintenance.py')
        #if not os.path.exists(DestFile): 
        #    from shutil import copyfile;copyfile(Source_maintenance, DestFile)
              
        return retVal        
        '''        
          
        '''
        #original        
        if fetch:
            tmpFile = os.path.join(self.basePath, 'tmp')
            if self.fileType == self.TYPE_REMOTE:
                xbmc.log('[Andy.plugin.program.Guide] file is in remote location: %s' % self.fileUrl, xbmc.LOGDEBUG)
                if not xbmcvfs.copy(self.fileUrl, tmpFile):
                    xbmc.log('[Andy.plugin.program.Guide] Remote file couldn\'t be copied: %s' % self.fileUrl, xbmc.LOGERROR)
            else:
                f = open(tmpFile, 'wb')
                xbmc.log('[Andy.plugin.program.Guide] file is on the internet: %s' % self.fileUrl, xbmc.LOGDEBUG)
                tmpData = urllib2.urlopen(self.fileUrl)
                data = tmpData.read()
                if tmpData.info().get('content-encoding') == 'gzip':
                    data = zlib.decompress(data, zlib.MAX_WBITS + 16)
                f.write(data)
                f.close()
            if os.path.getsize(tmpFile) > 256:
                if os.path.exists(self.filePath):
                    os.remove(self.filePath)
                os.rename(tmpFile, self.filePath)
                retVal = self.FETCH_OK
                xbmc.log('[Andy.plugin.program.Guide] file %s was downloaded' % self.filePath, xbmc.LOGDEBUG)
            else:
                retVal = self.FETCH_ERROR
        return retVal        
        '''         
        
        
