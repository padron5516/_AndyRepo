#example to run -  RunScript($CWD/iptv_maintenance.py)
#from __future__ import unicode_literals
#from collections import namedtuple
import argparse
import codecs
import sys,os,json,urllib2
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re
import shutil
addon = 'Andy.plugin.program.Guide';addon_name = addon;icon = xbmc.translatePath(os.path.join('special://home/addons', addon, 'icon.png'))
addonPath = xbmc.translatePath(os.path.join('special://home', 'addons', addon))
basePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon))
dbPath = xbmc.translatePath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
dialog = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
mode = 'ReplaceText'




#GRAB POSSIBLE CREDENTIALS
def Replace_These():

    #Get iptvsubs Pass
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.iptvsubs','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.iptvsubs','icon.png'))
    if os.path.exists(addonSettingsFile):
        Source_File = os.path.join(basePath, 'addons.ini')
        tmp_File = os.path.join(basePath, '_backup.ini')
        if os.path.exists(Source_File):        
            addon_name2='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona')         
            user_name_old='iptvsubsemail@gmail.com'       
            pass_word_old='iptvsubspass' 
            addon_name2='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
            #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("IPTVSubs","User and Pass added to addons.ini",3000, icon))
            #
            #beta
            user_name_old='iptvsubsemail@gmail.com'       
            pass_word_old='iptvsubspass' 
            addon_name2='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
            #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("IPTVSubs","User and Pass added to addons.ini",3000, icon))        
            #
            import iptvsubsm3u
     
        
    #Get DexterTV Pass
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.dex','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.dex','icon.png'))
    if os.path.exists(addonSettingsFile):
        username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')       
        Source_File = os.path.join(basePath, 'addons.ini')
        tmp_File = os.path.join(basePath, '_backup.ini')
        if os.path.exists(Source_File):        
            user_name_old='dexteremail@gmail.com'
            pass_word_old='dexterpass'      
            addon_name2='plugin.video.dex';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
            #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("DexterTV","User and Pass added to addons.ini",3000, icon))
     
     
     
     
     

    Replace_These_Builtin()




def Replace_These_Builtin():
    addon = 'Andy.plugin.program.Guide';addon_name = addon

    ####Create ini files####
    inipath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon,'ini'))
    #inipath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon))
    #if not os.path.exists(inipath):
    #    os.makedirs(inipath) 



    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z0.py'))
    if os.path.exists(addonSettingsFile):
        try:
            if not os.path.exists(inipath):
                os.makedirs(inipath) 
            import z0
            z0.z00() 
            #'''
            addonSettingsFile = xbmc.translatePath(os.path.join(inipath,'pvr.ini'))
            if os.path.exists(addonSettingsFile):
                 Source_File = addonSettingsFile
                 tmp_File = os.path.join(basePath, '_backup.ini')
                 user_name_old='script.on-tapp.tv'
                 pass_word_old=''
                 user_name='pvr.iptvsimple'
                 pass_word=''
                 ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
                 #
                 Dest_File = os.path.join(basePath, 'addons.ini')
                 if os.path.exists(Dest_File):
                     AppendText(Source_File, Dest_File)
                 #
                 Dest_File = os.path.join(basePath, 'addons2.ini')
                 if os.path.exists(Dest_File):
                     AppendText(Source_File, Dest_File)               

                 if os.path.exists(Source_File):
                     os.remove(Source_File)
            #'''
        except: pass
    

    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z1.py'))
    if os.path.exists(addonSettingsFile):
        try:
            if not os.path.exists(inipath):
                os.makedirs(inipath) 
            import z1
            z1.z11()
        except: pass
    #
    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z2.py'))
    if os.path.exists(addonSettingsFile):
        try:
            #if not os.path.exists(inipath):
                #os.makedirs(inipath) 
            import z2
            z2.z22()
        except: pass
    #
    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z3.py'))
    if os.path.exists(addonSettingsFile):
        try:
            if not os.path.exists(inipath):
                os.makedirs(inipath) 
            import z3
            z3.z33()
        except: pass
        

    #if os.path.exists(inipath):
    #    os.remove(inipath)





def AppendText(SourceFile, DestFile):
     s=open(SourceFile).read()
     f=open(DestFile,'a')
     f.write(s)
     f.close()
     #if os.path.exists(tmpFile):        
     #    os.remove(tmpFile)
     #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide","Done.",3000, icon))

def ReplaceText(SourceFile, tmpFile, usernameold, username, passwordold, password):
     if os.path.exists(tmpFile):
         os.remove(tmpFile)
     os.rename(SourceFile, tmpFile)
     s=open(tmpFile).read()

     s=s.replace(usernameold,username)
     s=s.replace(passwordold,password)
     f=open(SourceFile,'a')
     f.write(s)
     f.close()
     os.remove(tmpFile)
     #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide","Extra User and Pass added to ini",3000, icon))
         
if mode=='ReplaceText' : Replace_These()
