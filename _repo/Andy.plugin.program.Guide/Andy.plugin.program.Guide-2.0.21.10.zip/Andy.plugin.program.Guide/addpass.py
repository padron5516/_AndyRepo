#example to run -  RunScript($CWD/iptv_maintenance.py)
#from __future__ import unicode_literals
#from collections import namedtuple
import argparse
import codecs
import sys,os,json,urllib2
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re
import shutil
addon = 'Andy.plugin.program.Guide';addon_name = addon#,;icon = xbmc.translatePath(os.path.join('special://home/addons', addon, 'icon.png'))
addonPath = xbmc.translatePath(os.path.join('special://home', 'addons', addon))
basePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon))
dbPath = xbmc.translatePath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
dialog = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
mode = 'ReplaceText'


#GRAB POSSIBLE CREDENTIALS
def Replace_These():
    #Get iptvsubs Pass
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.iptvsubs','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.iptvsubs','icon.png'))
    if os.path.exists(addonSettingsFile):
        Source_File = os.path.join(basePath, 'addons.ini')
        tmp_File = os.path.join(basePath, '_backup.ini')
        user_name_old='iptvsubsemail@gmail.com'       
        pass_word_old='iptvsubspass' 
        addon_name2='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
        ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("IPTVSubs","User and Pass added to addons.ini",3000, icon))
        
    #Get DexterTV Pass
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.dex','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.dex','icon.png'))
    if os.path.exists(addonSettingsFile):
        username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')       
        Source_File = os.path.join(basePath, 'addons.ini')
        tmp_File = os.path.join(basePath, '_backup.ini')
        user_name_old='dexteremail@gmail.com'
        pass_word_old='dexterpass'      
        addon_name2='plugin.video.dex';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
        ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("DexterTV","User and Pass added to addons.ini",3000, icon))
     

    Replace_These_Builtin()



def Replace_These_Builtin():
    addon = 'Andy.plugin.program.Guide';addon_name = addon

    ####Create files####
    #import dixie
    inipath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon,'ini'))
    if not os.path.exists(inipath):
        os.makedirs(inipath) 


    try:
        import pvr
        pvr.createPVRINI()
    except: pass

    try:
        import plugins
        #plugins.checkAddons()
        plugins.getPlaylist()
    except: pass
       
    #this creates iptv subs and livemix
    try:
        import livetv
        livetv.checkAddons()
    except: pass
    
    
 


    #rename pvr path
    addonSettingsFile = xbmc.translatePath(os.path.join(inipath,'pvr.ini'))
    if os.path.exists(addonSettingsFile):
         Source_File = addonSettingsFile
         tmp_File = os.path.join(basePath, '_backup.ini')
         user_name_old='script.on-tapp.tv'
         pass_word_old=' cCloudTV.ORG (Top10) (US) (English)'
         #user_name='Andy.plugin.program.Guide'
         user_name='pvr.iptvsimple'
         pass_word=''
         ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
 
         Source_File = os.path.join(basePath, 'addons.ini')
         if os.path.exists(tmp_File):
             os.remove(tmp_File)
         #os.rename(Source_File, tmp_File)
         s=open(addonSettingsFile).read()
         f=open(Source_File,'a')
         f.write(s)
         f.close()
         os.remove(tmp_File)
          

    '''
    #rename pvr stuff
    addonSettingsFile = xbmc.translatePath(os.path.join(basePath,'addons.ini'))
    if os.path.exists(addonSettingsFile):
        Source_File = addonSettingsFile
        tmp_File = os.path.join(basePath, '_backup.ini')
        user_name_old='[pvr.iptvsimple-]'
        #user_name_old='[pvr.iptvsimple-]'
        pass_word_old=''
        #user_name='[Andy.pvr.iptvsimple]'
        user_name='[pvr.iptvsimple]'
        pass_word=''
        ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
    '''
        



















def ReplaceText(SourceFile, tmpFile, usernameold, username, passwordold, password):
     if os.path.exists(tmpFile):
         os.remove(tmpFile)
     os.rename(SourceFile, tmpFile)
     s=open(tmpFile).read()

     s=s.replace(usernameold,username)
     s=s.replace(passwordold,password)
     f=open(SourceFile,'a')
     f.write(s)
     f.close()
     os.remove(tmpFile)
     #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide","Extra User and Pass added to ini",3000, icon))
     
     
if mode=='ReplaceText' : Replace_These()
