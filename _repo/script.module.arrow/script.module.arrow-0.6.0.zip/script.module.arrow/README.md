script.module.arrow
======================

Python arrow library packed for Kodi.

See https://github.com/crsmithdev/arrow
