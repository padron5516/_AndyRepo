# -*- coding: utf-8 -*-


import re,urlparse,requests,urllib
from liveresolver.modules import client,jsunpack,unwise


def resolve(url):
	#swf='http://static.zoomtv.me/player/jwplayer.6.5.3.swf'
    session = requests.Session()
    referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
    session.headers.update({'referer': referer,
                             'User-agent' : 'Apple-iPhone/701.341',
                             'Host' : 'www.zoomtv.me',
                             'Origin' : urlparse.urlparse(referer).netloc,
                             })
    fid = urlparse.parse_qs(urlparse.urlparse(url).query)['v'][0]
    cx = urlparse.parse_qs(urlparse.urlparse(url).query)['cx'][0]
    pid = urlparse.parse_qs(urlparse.urlparse(url).query)['pid'][0]
    url = 'http://www.zoomtv.me/embed.php?v=%s&vw=660&vh=450'%fid
    post_data = {'cx' : cx,
    			'lg' : '1' ,
    			'pid' : pid }
    result = session.post(url, data = urllib.urlencode(post_data)).text
    result = re.compile("}\(('.+?' *, *'.+?' *, *'.+?' *, *'.+?')\)").findall(result)[-1]
    result = unwise.execute(result)
    print(result)
    return