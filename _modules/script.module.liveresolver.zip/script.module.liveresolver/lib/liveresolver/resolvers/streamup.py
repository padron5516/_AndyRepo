# -*- coding: utf-8 -*-


import re,urlparse,json
from liveresolver.modules import client


def resolve(url):
    try:
        try: referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
        except: referer = url
        id = urlparse.parse_qs(urlparse.urlparse(url).query)['id'][0]
        uri = 'http://streamup-lancer.herokuapp.com/api/redirect/%s'%id
        result = client.request(uri,referer='http://streamup.com')
        url = 'http://'+result+'/app/%ss-stream/playlist.m3u8'%id
        return url
    except:
       return


