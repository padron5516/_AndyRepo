import os
import sys
import re
import xbmc
import xbmcplugin
import xbmcgui
import urllib
import unicodedata
from dudehere.routines import *
from dudehere.routines.i18n import i18n
from dudehere.routines.vfs import VFSClass

VIEWS = enum(DEFAULT=500, LIST=50, BIGLIST=51, THUMBNAIL=500, SMALLTHUMBNAIL=522, FANART=508, POSTERWRAP=501, MEDIAINFO=504, MEDIAINFO2=503, MEDIAINFO3=515, WIDE=505, LIST_DEFAULT=50, TV_DEFAULT=515, MOVIE_DEFAULT=551, SEASON_DEFAULT=50, EPISODE_DEFAULT=515)
	
vfs = VFSClass()
class ContextMenu:
	def __init__(self):
		self.commands = []

	def add(self, text, arguments={}, script=False, visible=True):
		if hasattr(visible, '__call__'):
			if visible() is False: return
		else:
			if visible is False: return
		cmd = self._build_url(arguments, script)
		self.commands.append((text, cmd, ''))
	
	def _build_url(self, arguments, script):
		plugin_url =  "%s?%s" % (ADDON_URL, urllib.urlencode(arguments))
		if script:
			cmd = 'XBMC.RunPlugin(%s)' % (plugin_url)
		else:
			cmd = "XBMC.Container.Update(%s)" % plugin_url
		return cmd

	def get(self):
		return self.commands


class Plugin():
	default_context_menu_items = []
	def __init__(self):
		self.args = ADDON.parse_query(sys.argv[2])
		self.dispatcher = {}
		self.kargs = {}
		self.ENABLE_DEFAULT_VIEWS = True
		self.replace_context_menu_by_default = False
		if self.args['mode'] is None:
			self.mode='main'
		else:
			self.mode = self.args['mode']	
	
	def arg(self, k):
		if k in self.args.keys():
			return self.args[k]
		else:
			return None
	
	def normalize(self, string):
		return unicodedata.normalize('NFKD',unicode(string.encode('utf-8'))).encode('utf-8','ignore')
		
	def register(self, mode, target, kargs=None):
		if isinstance(mode, list):
			for foo in mode:
				self.dispatcher[foo] = target
				self.kargs[foo] = kargs
		else:
			self.dispatcher[mode] = target
			self.kargs[mode] = kargs
		
	def run(self):
		if ADDON.get_setting('setup_run') != 'true':
			self.first_run()
			
		if self.kargs[self.args['mode']] is None:
			self.dispatcher[self.args['mode']]()
		else:
			self.dispatcher[self.args['mode']](*self.kargs[self.args['mode']])
	
	def first_run(self):
		pass
	
	def set_default_context_menu(self, items):
		self.default_context_menu_items = items
		
	def add_menu_item(self, query, infolabels, total_items=0, image='', fanart='', menu=None, replace_menu=None, visible=True):
		if hasattr(visible, '__call__'):
			if visible() is False: return
		else:
			if visible is False: return
		if isinstance( infolabels['title'], ( int, long ) ):
			infolabels['title'] = i18n(infolabels['title'])
		if replace_menu is None:
			replace_menu = self.replace_context_menu_by_default
		if menu is None:
			menu = ContextMenu()
		for m in self.default_context_menu_items:
			menu.add(*m)
		#menu.add('Enable/Disable Scrapers', {"mode": "scraper_list"}, script=True)
		if not fanart:
			fanart = ROOT_PATH + '/fanart.jpg'
		#infolabels['title'] = self.normalize(infolabels['title'])
		listitem = xbmcgui.ListItem(infolabels['title'], iconImage=image, thumbnailImage=image)
		listitem.setInfo('video', infolabels)
		listitem.setProperty('IsPlayable', 'false')
		listitem.setProperty('fanart_image', fanart)
		if menu:
			listitem.addContextMenuItems(menu.get(), replaceItems=replace_menu)
		plugin_url = self.build_plugin_url(query)
		xbmcplugin.addDirectoryItem(HANDLE_ID, plugin_url, listitem, isFolder=True, totalItems=total_items)

	
	def add_video_item(self, query, infolabels, total_items=0, image='', fanart='', menu=None, replace_menu=None):
		#infolabels['title'] = self.normalize(infolabels['title'])
		listitem = xbmcgui.ListItem(infolabels['title'], iconImage=image, thumbnailImage=image)
		listitem.setInfo("video", infolabels)
		listitem.setProperty('IsPlayable', 'true')
		listitem.setProperty('fanart_image', fanart)
		if replace_menu is None:
			replace_menu = self.replace_context_menu_by_default
		if menu is None:
			menu = ContextMenu()
		for m in self.default_context_menu_items:
			menu.add(*m)	
		#menu.add('Enable/Disable Scrapers', {"mode": "scraper_list"}, script=True)
		if menu:
			listitem.addContextMenuItems(menu.get(), replaceItems=replace_menu)
		plugin_url = self.build_plugin_url(query)
		xbmcplugin.addDirectoryItem(HANDLE_ID, plugin_url, listitem, isFolder=False, totalItems=total_items)
		
	def build_plugin_url(self, query):
		return "%s?%s" % (ADDON_URL, urllib.urlencode(query))
	
	def execute_query(self, query):
		plugin_url = self.build_plugin_url(query)
		self.execute_url(plugin_url)
	
	def execute_url(self, plugin_url):
		cmd = 'XBMC.RunPlugin(%s)' % (plugin_url)
		self.run_command(cmd)
	
	def run_command(self, cmd):
		xbmc.executebuiltin(cmd)
	
	def play_url(self, plugin_url):
		cmd = 'XBMC.PlayMedia(%s)' % (plugin_url)
		self.run_command(cmd)
		
	def eod(self, view=VIEWS.DEFAULT, content=None, viewid=None):
		if view=='custom':
			self.set_view('custom', content=content, viewid=viewid)
		else:
			self.set_view(view,content=content)
		xbmcplugin.endOfDirectory(HANDLE_ID)
	
	def set_view(self, view, content=None, viewid=None):
		if self.ENABLE_DEFAULT_VIEWS:
			if content:
				xbmcplugin.setContent(int(sys.argv[1]), content)
			if not viewid:
				viewid = view
			xbmc.executebuiltin("Container.SetViewMode(%s)" % viewid)
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )	
	
	def dialog_input(self, title):
		kb = xbmc.Keyboard('', title, False)
		kb.doModal()
		if (kb.isConfirmed()):
			text = kb.getText()
			if text != '':
				return text
		return None	
	
	def show_textbox(self, heading, content):
		TextBox().show(heading, content)
	
	def dialog_ok(self, title="", m1="", m2="", m3=""):
		dialog = xbmcgui.Dialog()
		dialog.ok(title, m1, m2, m3)
	
	def confirm(self, title, m1='', m2=''):
		dialog = xbmcgui.Dialog()
		return dialog.yesno(title, m1, m2)
	
	def dialog_select(self, heading, options):
		dialog = xbmcgui.Dialog()
		index = dialog.select(heading, options)
		print index
		if index >= 0:
			return index
		else: 
			return False
	
	def notify(self, title, message, timeout=1500, image=vfs.join(ROOT_PATH, 'icon.png')):
		cmd = "XBMC.Notification('%s', '%s', %s, %s)" % (title, message, timeout, image)
		xbmc.executebuiltin(cmd)
		
	def error_message(self, title, message, timeout=2500, image=vfs.join(ROOT_PATH, 'icon.png')):
		cmd = "XBMC.Notification('%s', '%s', %s, %s)" % (title, message, timeout, image)
		xbmc.executebuiltin(cmd)	
		
	def refresh(self):
		xbmc.executebuiltin("Container.Refresh")
	
	def exit(self):
		exit = xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
		return exit
	
	def kodi_json_request(self, method, params):
		jsonrpc =  json.dumps({ "jsonrpc": "2.0", "method": method, "params": params, "id": 1 })
		response = json.loads(xbmc.executeJSONRPC(jsonrpc))
		return response
	
	def get_movieid(self, title, year):
		params = { "filter": {"and": [
			{"field": "title", "operator": "is", "value": str(title)},
			{"field": "year", "operator": "is", "value": str(year)}
		]}}
		response = self.kodi_json_request('VideoLibrary.GetMovies', params)
		try:
			return response['result']['movies'][0]['movieid']
		except:
			return False

	def get_episodeid(self, show_title, season, episode):
		params = { "filter": {"and": [
			{"field": "tvshow", "operator": "is", "value": show_title}, 
			{"field": "season", "operator": "is", "value": str(season)}, 
			{"field": "episode", "operator": "is", "value": str(episode)}
		]}, "properties": ["playcount"]}
		response = kodi_json_request('VideoLibrary.GetEpisodes', params)
		try:
			return response['result']['episodes'][0]['episodeid']
		except:
			return False
	
	def get_movie_playcount(self, movie, year):
		params = { "filter": {"and": [
			{"field": "title", "operator": "is", "value": movie},
			{"field": "year", "operator": "is", "value": str(year)}
		]}, "properties": ["playcount"]}
		response = self.kodi_json_request('VideoLibrary.GetMovies', params)
		try:
			return response['result']['movies'][0]['movieid'],response['result']['movies'][0]['playcount']
		except:
			return False,False
	
	def get_episode_playcount(self, show_title, season, episode):
		params = { "filter": {"and": [
			{"field": "tvshow", "operator": "is", "value": show_title}, 
			{"field": "season", "operator": "is", "value": str(season)}, 
			{"field": "episode", "operator": "is", "value": str(episode)}
		]}, "properties": ["playcount"]}
		response = self.kodi_json_request('VideoLibrary.GetEpisodes', params)
		try:
			return response['result']['episodes'][0]['episodeid'], response['result']['episodes'][0]['playcount']
		except:
			return False,False
	

	def play_stream(self, url,  metadata={"cover_url": "", "title": ""}, title=None):
		if title is None: title = metadata['title']
		listitem = xbmcgui.ListItem(title, iconImage=metadata['cover_url'], thumbnailImage=metadata['cover_url'], path=url)
		listitem.setProperty('IsPlayable', 'true')
		listitem.setPath(url)
		listitem.setInfo("video", metadata)
		win = xbmcgui.Window(10000)
		win.setProperty('GenericPlaybackService.playing', "true")
		try:
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
		except Exception, e:
			ADDON.log( e )

class ProgressBar(xbmcgui.DialogProgress):
	def __init__(self, *args, **kwargs):
		xbmcgui.DialogProgress.__init__(self, *args, **kwargs)
		self._silent = False
		self._index = 0
		self._total = 0
		self._percent = 0
		
	def new(self, heading, total):
		if not self._silent:
			self._index = 0
			self._total = total
			self._percent = 0
			self._heading = heading
			self.create(heading)
			self.update(0, heading, '')
	def update_subheading(self, subheading):
		self.update(self._percent, self._heading, subheading)
		
	def next(self, subheading):
		if not self._silent:
			self._index = self._index + 1
			self._percent = self._index * 100 / self._total
			self.update(self._percent, self._heading, subheading)
		
class TextBox:
	# constants
	WINDOW = 10147
	CONTROL_LABEL = 1
	CONTROL_TEXTBOX = 5

	def __init__( self, *args, **kwargs):
		# activate the text viewer window
		xbmc.executebuiltin( "ActivateWindow(%d)" % ( self.WINDOW, ) )
		# get window
		self.window = xbmcgui.Window( self.WINDOW )
		# give window time to initialize
		xbmc.sleep( 500 )


	def setControls( self ):
		#get header, text
		heading, text = self.message
		# set heading
		self.window.getControl( self.CONTROL_LABEL ).setLabel( "%s - %s v%s" % ( heading, ADDON_NAME, VERSION) )
		# set text
		self.window.getControl( self.CONTROL_TEXTBOX ).setText( text )

	def show(self, heading, text):
		# set controls

		self.message = heading, text
		self.setControls()		