import sys
import os
import re
import urllib, urllib2
import json
import unicodedata
import xbmcgui
import urlresolver
import hashlib
from urlparse import urljoin
from dudehere.routines import *
from dudehere.routines.threadpool import ThreadPool
from addon.common.net import Net, HttpResponse
from BeautifulSoup import BeautifulSoup
from dudehere.routines.vfs import VFSClass
from dudehere.routines.plugin import ProgressBar
vfs = VFSClass()
DECAY = 2
SCRAPER_DIR = os.path.dirname(os.path.abspath(__file__))
COOKIE_PATH = vfs.join(DATA_PATH,'cookies')
if not vfs.exists(COOKIE_PATH): vfs.mkdir(COOKIE_PATH, recursive=True)
sys.path.append(SCRAPER_DIR)
from dudehere.routines.database import SQLiteDatabase as DatabaseAPI	
class MyDatabaseAPI(DatabaseAPI):
	def _initialize(self):
		tables = [
			'''
			CREATE TABLE IF NOT EXISTS "search_cache" (
			"cache_id" INTEGER PRIMARY KEY AUTOINCREMENT, 
			"hash" TEXT NOT NULL,
			"service" TEXT NOT NULL,
			"host" TEXT NOT NULL,
			"display" TEXT NOT NULL,
			"quality" INTEGER DEFAULT 3,
			"url" TEXT NOT NULL, 
			"ts" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)
			''',
			'''
			CREATE TABLE IF NOT EXISTS "scraper_states" (
			"id"	INTEGER PRIMARY KEY AUTOINCREMENT,
			"name"	TEXT UNIQUE,
			"enabled"	INTEGER DEFAULT 1
			)
			'''
		]
		for SQL in tables:
			self.execute(SQL)
		self.commit()
		ADDON.set_setting('database_init_sqlite', 'true')
DB_TYPE = 'sqlite'
DB_FILE = vfs.join(DATA_PATH, "cache.db")
#DB=MyDatabaseAPI(DB_FILE)

class NetLib(Net):
	timeout=1
	def get(self, url, headers=None, timeout=1):
		self.timeout = timeout
		html = self.http_GET(url, headers=headers)
		return html
	
	def post(self, url, params, headers=None, timeout=1):
		self.timeout = timeout
		html = self.http_POST(url, params, headers=headers)
		return html
		
	def _fetch(self, url, form_data={}, headers={}, compression=True):
		encoding = ''
		req = urllib2.Request(url)
		if form_data:
			form_data = urllib.urlencode(form_data)
			req = urllib2.Request(url, form_data)
		req.add_header('User-Agent', self._user_agent)
		for k, v in headers.items():
			req.add_header(k, v)
		if compression:
			req.add_header('Accept-Encoding', 'gzip')
		try:
			response = urllib2.urlopen(req, timeout=self.timeout)
		except urllib2.HTTPError as e:
			ADDON.log("HTTP Error: %s" % e.code)
			return ''
		return HttpResponse(response).content

class ScraperResult():
	bitrate_color = 'purple'
	hostname_color = 'red'
	size_color = 'blue'
	extension_color = 'green'
	quality_color = 'yellow'
	service_color = 'white'

	
	def __init__(self, service, hostname, url, text=None):
		self.hostname = hostname
		self.service = service
		self.text = text
		self.url = url
		self.bitrate = None
		self.size = None
		self.extension = None
		self.quality = None
	
	def colorize(self, attrib, value):
		color = getattr(self, attrib+'_color')
		if attrib == 'bitrate':
			return "[COLOR %s]%s kb/s[/COLOR]" % (color, value)
		elif attrib == 'quality':
			quality = QUALITY.r_map[value]
			return "[COLOR %s]%s[/COLOR]" % (color, quality)
		else:
			return "[COLOR %s]%s[/COLOR]" % (color, value)
		
	def ck(self, attrib):
		if getattr(self, attrib):
			self.attributes.append(self.colorize(attrib, getattr(self, attrib)))
		
	def format(self):
		self.attributes = []
		self.attributes.append(self.colorize('hostname', self.hostname))
		self.attributes.append(self.colorize('service', self.service))
		for foo in ['size', 'bitrate', 'extension', 'quality']:
			self.ck(foo)
		
		format = "[%s]: %s"	
		if self.text is None: self.text = self.hostname
		return format % (' | '.join(self.attributes), self.text)

class CommonScraper():
	USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36'
	ACCEPT = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
	HOST_COLOR = 'red'
	SIZE_COLOR = 'blue'
	EXTENSION_COLOR = 'green'
	QUALITY_COLOR = 'yellow'
	BITRATE_COLOR = 'purple'
	timeout = 1
	broken = False
	require_auth = False
	
	def __init__(self, load = None, disable = None, cache_results=False):
		self.threadpool_size = 5
		self.cache_results = cache_results
		self._load_list = load
		self._disable_list = disable
		self.enabled_scrapers = 0
		self.active_scrapers = []
		self.supported_scrapers = []
		self._active_scrapers = []
		self._load_scrapers()
		self._enable_scrapers()
		self.search_results = []
	
	def normalize(self, string):
		return unicodedata.normalize('NFKD', unicode(string)).encode('utf-8','ignore')
	
	def get_setting(self, k):
		return self._settings[k]
	
	def set_setting(self, k, v):
		self._settings[k] = v
	
	def read_scraper_states(self):
		DB=MyDatabaseAPI(DB_FILE)
		return DB.query_assoc("SELECT name, enabled FROM scraper_states")
		DB.disconnect()
	
	def toggle_scraper_state(self, name):
		DB=MyDatabaseAPI(DB_FILE)
		DB.execute("UPDATE scraper_states SET enabled = (enabled * -1 + 1) WHERE name=?",  [name])
		DB.commit()
		DB.disconnect
		
	def set_scraper_state(self, name, state):
		DB=MyDatabaseAPI(DB_FILE)
		state = 1 if state else 0
		DB.execute("UPDATE scraper_states SET enabled = ? WHERE name=?",  [state, name])
		DB.commit()
		DB.disconnect
		
	def _load_scrapers(self):
		DB=MyDatabaseAPI(DB_FILE)
		names = []
		count = 0
		for filename in sorted(os.listdir(SCRAPER_DIR)):
			if not re.search('(__)|(common\.py)|(example\.py)|(all\.py)', filename) and re.search('py$', filename):
				name = filename[0:len(filename)-3]
				self.supported_scrapers.append(name)
				names.append([name])
				if self._load_list is False: continue 	#should I even load anything?
				skip = False
				
				if self._load_list == 'all':
					pass 					#load all except explicitly disabled
				elif isinstance(self._load_list, list):
					skip = True				#load all in the supplied load list except explicitly disabled
					if name in self._load_list: skip = False
				else:
					skip = True				#load all enabled from db except explicitly disabled
					if DB.query("SELECT 1 FROM scraper_states WHERE enabled AND name=?", [name]): skip = False
						
				if self._disable_list is not None:
					if name in self._disable_list:
						skip = True			#now disable any scrapers in the disable list
				if skip is False:	
					classname = name+'Scraper'
					scraper = __import__(name, globals(), locals(), [classname], -1)
					klass = getattr(scraper, classname)
					scraper = klass()
					self.put_scraper(scraper.service, scraper)
				count +=1
		if count > DB.query("SELECT count(1) FROM scraper_states")[0]:
			for name in names: DB.execute("INSERT INTO scraper_states(name) VALUES (?)", name)
			DB.commit()
		DB.disconnect()
				
	def get_scraper_by_name(self, name):
		try:
			index = self.active_scrapers.index(name)
			return self.get_scraper_by_index(index)
		except:
			return None
		
	def get_scraper_by_index(self, index):
		try:
			return self._active_scrapers[index]
		except:
			return None
	
	def _enable_scrapers(self):
		for index in range(0, len(self.active_scrapers)):
			self.enabled_scrapers += 1
		
	def put_scraper(self, name, scraper):
		if not scraper.broken:
			self.active_scrapers.append(name)
			self._active_scrapers.append(scraper)
		
	def process_results(self, results):
		if self.cache_results:
			values = []
			for r in results: values.append([self.hashid, r.service, r.hostname, r.format(), r.quality, r.url])
			DB=MyDatabaseAPI(DB_FILE)
			DB.execute_many("INSERT INTO search_cache(hash, service, host, display, quality, url) VALUES(?,?,?,?,?,?)", values)
			DB.commit()
		self.search_results += results
		
	def search_tvshow(self, showname, season, episode, year=None, imdb_id=None, tvdb_id=None):
		if self.cache_results:
			DB=MyDatabaseAPI(DB_FILE)
			self.hashid = hashlib.md5(showname+str(season)+str(episode)).hexdigest()
			DB.execute("DELETE FROM search_cache WHERE hash=? AND strftime('%s','now') -  strftime('%s',ts) > (3600 * ?)", [self.hashid, DECAY])
			DB.commit()
		self._get_active_resolvers()
		args = {"showname": showname, "season": season, "episode": episode, "year": year, "domains": self.domains, "imdb_id": imdb_id, "tmdb_id": tvdb_id}
		workers = ThreadPool(self.threadpool_size)
		for index in range(0, self.enabled_scrapers):
			service = self.get_scraper_by_index(index).service
			if self.cache_results:
				SQL = '''
					SELECT
					"%s" AS hashid,
					"%s" AS service,
					host,
					display as title,
					url,
					quality,''' % (self.hashid, service)
				SQL += '''strftime("%s",'now') -  strftime("%s",ts) < (3600 * ?) AS fresh
				FROM search_cache 
				WHERE
				hash=? AND service=?
				'''
				cached = DB.query_assoc(SQL, [DECAY, self.hashid, service])
			else:
				cached = False
			if cached:
				self.search_results += cached
			else:
				if 'search_tvshow' in dir(self.get_scraper_by_index(index)):
					add_task = True
					if self.get_scraper_by_index(index).require_auth and (DDON.get_setting(self.get_scraper_by_index(index).service + '_username') == '' or ADDON.get_setting(self.get_scraper_by_index(index).service + '_password') == ''): add_task = False
					if add_task: workers.queueTask(self.get_scraper_by_index(index).search_tvshow, args=args, taskCallback=self.process_results)
		workers.joinAll()
		resolved_url = None
		raw_url =  self.select_stream()
		if raw_url:
			resolved_url = self.resolve_url(raw_url)
		return resolved_url	
	
	def search_movie(self, title, year, imdb_id=None, tmdb_id=None):
		if self.cache_results:
			DB=MyDatabaseAPI(DB_FILE)
			self.hashid = hashlib.md5(title+str(year)).hexdigest()
			DB.execute("DELETE FROM search_cache WHERE hash=? AND strftime('%s','now') -  strftime('%s',ts) > (3600 * ?)", [self.hashid, DECAY])
			DB.commit()
		self._get_active_resolvers()
		args = {"title": title, "year": year, "domains": self.domains, "imdb_id": imdb_id, "tmdb_id": tmdb_id}
		workers = ThreadPool(self.threadpool_size)
		for index in range(0, self.enabled_scrapers):
			if self.cache_results:
				service = self.get_scraper_by_index(index).service
				SQL = '''
					SELECT
					"%s" AS hashid,
					"%s" AS service,
					host,
					display as title,
					url,
					quality,''' % (self.hashid, service)
				SQL += '''strftime("%s",'now') -  strftime("%s",ts) < (3600 * ?) AS fresh
				FROM search_cache 
				WHERE
				hash=? AND service=?
				'''
				cached = DB.query_assoc(SQL, [DECAY, self.hashid, service])
			else:
				cached = False	
			if cached:
				self.search_results += cached
			else:
				if 'search_movie' in dir(self.get_scraper_by_index(index)):
					add_task = True
					if self.get_scraper_by_index(index).require_auth and (DDON.get_setting(self.get_scraper_by_index(index).service + '_username') == '' or ADDON.get_setting(self.get_scraper_by_index(index).service + '_password') == ''): add_task = False
					if add_task: workers.queueTask(self.get_scraper_by_index(index).search_movie, args=args, taskCallback=self.process_results)
		workers.joinAll()
		resolved_url = None
		raw_url =  self.select_stream()
		if raw_url:
			resolved_url = self.resolve_url(raw_url)
		return resolved_url	
	
	def _get_active_resolvers(self):		
		self.domains = []
		try:
			for resolver in urlresolver.UrlResolver.implementors():
				for self.domain in resolver.domains:
					if re.match('^(.+?)\.(.+?)$', domain): self.domains.append(domain)
		except:
			pass
		if len(self.domains) ==0:
			self.domains = ['promptfile.com', 'crunchyroll.com', 'xvidstage.com', 'yourupload.com', 'dailymotion.com', 'cloudy.ec', 'cloudy.eu', 'cloudy.sx', 'cloudy.ch', 'cloudy.com', 'thevideo.me', 'videobb.com', 'stagevu.com', 'mp4stream.com', 'youwatch.org', 'rapidvideo.com', 'play44.net', 'castamp.com', 'daclips.in', 'daclips.com', 'videozed.net', 'videomega.tv', 'movieshd.co', 'bayfiles.com', 'vidzi.tv', 'vidxden.com', 'vidxden.to', 'divxden.com', 'vidbux.com', 'vidbux.to', 'purevid.com', 'thefile.me', 'shared.sx', 'vimeo.com', 'vidplay.net', 'vidspot.net', 'movshare.net', 'speedvideo.net', 'uploadc.com', 'streamcloud.eu', 'sockshare.com', 'vk.com', 'videohut.to', 'letwatch.us', 'royalvids.eu', 'veoh.com', 'donevideo.com', 'mp4star.com', 'vidto.me', 'vivo.sx', 'videotanker.co', 'hugefiles.net', 'youtube.com', 'youtu.be', 'primeshare.tv', 'sharevid.org', 'sharerepo.com', 'video44.net', 'billionuploads.com', 'realvid.net', 'filenuke.com', 'bestreams.net', 'exashare.com', 'limevideo.net', 'videovalley.net', 'divxstage.eu', 'divxstage.net', 'divxstage.to', 'cloudtime.to', 'vidzur.com', 'gorillavid.in', 'gorillavid.com', 'trollvid.net', 'ecostream.tv', 'muchshare.net', 'streamin.to', 'video.tt', '180upload.com', 'auengine.com', 'novamov.com', 'vodlocker.com', 'watchfreeinhd.com', 'uploadcrazy.net', 'tubeplus.me', 'mp4upload.com', 'cyberlocker.ch', 'googlevideo.com', 'picasaweb.google.com', 'jumbofiles.com', 'vidstream.in', 'veehd.com', 'movdivx.com', 'mightyupload.com', 'vidup.org', 'tune.pk', 'facebook.com', 'mrfile.me', 'nowvideo.eu', 'nowvideo.ch', 'nowvideo.sx', 'flashx.tv', 'videoboxone.com', 'vidcrazy.net', 'movreel.com', 'hostingbulk.com', 'played.to', 'putlocker.com', 'filedrive.com', 'firedrive.com', 'mooshare.biz', 'zalaa.com', 'playwire.com', 'vidbull.com', 'sharesix.com', 'movpod.net', 'movpod.in', 'justmp4.com', 'cloudyvideos.com', 'mega-vids.com', 'nosvideo.com', 'movzap.com', 'zuzvideo.com', 'allmyvideos.net', 'videofun.me', 'videoweed.es', 'videoraj.ec', 'videoraj.eu', 'videoraj.sx', 'videoraj.ch', 'videoraj.com']
		
	def resolve_url(self, raw_url):
		test = re.search("^(.+?)(://)(.+?)$", raw_url)
		scraper = test.group(1)
		raw_url = test.group(3)
		if 'get_resolved_url' in dir(self.get_scraper_by_name(scraper)):
			resolved_url = self.get_scraper_by_name(scraper).get_resolved_url(raw_url)
			return resolved_url
		else:
			source = urlresolver.HostedMediaFile(url=raw_url)
			resolved_url = source.resolve() if source else None
			return resolved_url

	
	def select_stream(self):
		streams = []
		options = []
		def sort_streams(record):
			try:
				return (record.quality, record.hostname)
			except:
				return (record['quality'], record['host'])
		
		self.search_results.sort(reverse=True, key=lambda k: sort_streams(k))

		for result in self.search_results:
			try:
				streams.append(result.format())
				options.append(result.url)
			except:
				streams.append(result['title'])
				options.append(result['url'])	
		dialog = xbmcgui.Dialog()
		select = dialog.select("Select a stream", streams)
		if select < 0:
			return False
		return options[select]
	
	def test_quality(self, string):
		if re.search('1080p', string): return QUALITY.HD1080
		if re.search('720p', string): return QUALITY.HD720
		if re.search('480p', string): return QUALITY.SD480
		if re.search('(320p)|(240p)', string): return QUALITY.LOW
		return QUALITY.UNKNOWN
	
	def set_color(self, text, color):
		return "[COLOR %s]%s[/COLOR]" % (color, text)
	
	def format_size(self, size):
		size = int(size) / (1024 * 1024)
		if size > 2000:
			size = size / 1024
			unit = 'GB'
		else :
			unit = 'MB'
		size = "%s %s" % (size, unit)
		return size
	
	def request(self, uri, params=None, query=None, headers=None, timeout=None, return_soup=False, return_json=False):
		COOKIE_JAR = vfs.join(COOKIE_PATH,self.service + '.lwp')
		net = NetLib()
		net.set_cookies(COOKIE_JAR)
		if headers:
			headers['Referer'] = self.referrer
			headers['Accept'] = self.ACCEPT
			headers['User-Agent'] = self.USER_AGENT
		else:
			headers = {
			'Referer': self.referrer,
			'Accept': self.ACCEPT,
			'User-Agent': self.USER_AGENT
			}
		if query:
			uri += "?" + urllib.urlencode(query)
		url = urljoin(self.base_url, uri)
		if timeout is None:
			timeout = self.timeout
		if params:
			html = net.post(url, params, headers=headers, timeout=timeout)
		else:
			html = net.get(url, headers=headers, timeout=timeout)
		net.save_cookies(COOKIE_JAR)
		if return_soup:
			return BeautifulSoup(html)
		elif return_json:
			return json.loads(html)
		else: 
			return html
				
	def get_redirect(self, uri):
		from dudehere.routines import httplib2
		h = httplib2.Http()
		h.follow_redirects = True
		(response, body) = h.request(self.base_url + uri)
		return response['content-location']
			