import xbmc
import xbmcgui
import time
import math
from datetime import datetime, date
from lib.dudehere.routines import *

WINDOW_PREFIX = 'GenericPlaybackService'

class PlaybackService(xbmc.Player):
	def __init__(self, *args, **kwargs):
		xbmc.Player.__init__(self, *args, **kwargs)
		self.win = xbmcgui.Window(10000)
		self.initiated = datetime.now()
		self.__tracking 			= False
		self.__current_time 		= 0
		self.__total_time		= 0
		self.__percent 			= 0
	
	def log(self, message):
		xbmc.log("%s Service: %s" %(WINDOW_PREFIX, message))
	
	def set_property(self, k, v):
		self.win.setProperty(WINDOW_PREFIX + '.' + k, v)
	
	def get_property(self, k):
		return self.win.getProperty(WINDOW_PREFIX + '.' + k)
		
	def onPlayBackStarted(self):
		self.__tracking = self.get_property('playing') == 'True'
		if self.__tracking:
			self.log("Now I'm playing")
			self.__total_time = self.getTotalTime()
			self.set_property('playing', "false")

	def onPlayBackStopped(self):
		if self.__tracking:
			percent = int(self._current_time * 100 / self._total_time )
			self.log("Now I'm stopped at %s, %s of %s") % (self.__current_time, self.__percent, self.__total_time)	

	def onPlayBackEnded(self):
		self.onPlayBackStopped()

	def start(self):
		if ADDON.get_setting('enable_playback_service') != 'true': return
		monitor = xbmc.Monitor()
		self.log("Starting...")
		while True:
			if monitor.waitForAbort(1):
				break
			if self.isPlaying() and self.__tracking:
				self.__current_time = self.getTime()

		self.log("Service stopping...") 

if __name__ == '__main__':
	server = PlaybackService()
	server.start()