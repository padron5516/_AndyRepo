import xbmc
import xbmcgui

import time
import copy 

import boogietools as bt

notifications={"red":"[COLOR red]%s",
 		    "orange":"[COLOR orange]%s",
			 "green":"[COLOR green]%s",
		    "online":"Channel is Online",
		   "offline":"Channel is Offline",
			 "check":"Checking...",
			  "live":"Live!",
			  "dead":"Dead",
 		   "waiting":"Waiting for %s : %ds",
			}


class sportsui(xbmcgui.WindowXMLDialog):
	def __init__(self,strXMLname="sports.xml", strFallbackPath=None, strDefaultName='Default', forceFallback="720p"):
		pass

	def onInit(self):
		self.progress=self.getControl(2)
		self.lst=self.getControl(6)
		self.note=self.getControl(7)
	
	def setPlayer(self,player):
		self.player=player
		self.player.ui=self

	def onAction(self, action):
		if action.getId() in [10,92] :
			self.close()

	def onClick(self, controlID):
		if(self.player.splay(self.lst.getSelectedItem())==0):
			self.close()

	def onFocus(self, controlID):
		pass

	def addListItem(self,listItem):
		self.lst.addItem(listItem)
		if self.lst.size()==1: 
			self.setFocus(self.lst)
		else:
			focusid=self.getFocusId()
			sid=self.lst.getSelectedPosition()
			if focusid==6:
				self.lst.selectItem(sid)
			else:
				self.setFocusId(focusid)



class splayer(xbmc.Player):
	def __init__(self,*args, **kwargs):
		# a stateful player
		self.deftimeout=int(kwargs.get("timeout",20))
		self.alive=False
		xbmc.Player.__init__(self)

	def notification(self,percent,msg):
		if percent==0:
			self.progres=xbmcgui.DialogProgress()
			self.progres.create("SPlayer",msg)
		elif percent==100:
			self.progres.close()
		else:
			self.progres.update(percent,msg)

	def scraper(self,li):
		return li.getProperty("path")

	def postprocess(self,li):
		return li

	def create_item(self,li):
		return copy.copy(li)
		
	def splay(self,li,tout=None,silent=False):
		#returns 0:alive,1:scraper error,2:dead
		cname=bt.getliprop(li,"link")
		if tout is None:
			self.timeout=self.deftimeout
		else:
			self.timeout=tout
		stream=self.scraper(li,self.timeout)
		if stream is None:
			ret=1
		else:
			self.play(stream,self.create_item(li))
			time.sleep(1)
			self.timeout-=1
			if self.isPlaying:
				if not silent:
					self.notification(0,notifications["waiting"]%(cname,self.timeout))
				factor=5
				for i in range(self.timeout*factor):
					if self.alive or not self.isPlaying():
						break
#					if not silent and self.progres.iscanceled():
#						self.stop()
#						self.notification(100,"")
#						return li
					xbmc.sleep(1000/factor)
					if not silent:
						self.notification(100*i/self.timeout/factor,notifications["waiting"]%(cname,self.timeout-i/factor))
			if not silent:
				self.notification(100,"")
			if not self.alive:
				self.stop()
				bt.notify(cname,notifications["offline"])
				bt.setliprop(li,"status",notifications["red"]%notifications["dead"])
				bt.setliprop(li,"last_check",time.time())
				ret=2
			else:
				bt.setliprop(li,"status",notifications["green"]%notifications["live"])
				bt.setliprop(li,"last_check",time.time())
				ret=0
			self.alive=False
		self.postprocess(li)
		return ret

	def onPlayBackStarted(self):
		self.alive=True