Stem is a Python controller library
that allows applications to interact
with Tor (https://www.torproject.org/).